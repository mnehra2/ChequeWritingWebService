﻿namespace StudentReport
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // Variables for class calculations
            int vStudentCount = StudentData.vx;

            double vTotalGPA = 0;
            double vClassGPA = 0;

            int vPassCount = 0;
            int vFailCount = 0;

            // Display total number of students
            lblStudentCount.Text = "Total Students: " + vStudentCount;

            // Loop through all students
            for (int vInd = 0; vInd < vStudentCount; vInd++)
            {
                Student student = StudentData.Students[vInd];

                // Add student's GPA to total
                vTotalGPA = vTotalGPA + student.GPA;

                // Count students who passed or failed
                if (student.GPA >= Constant.PassedMarks)
                {
                    vPassCount++;
                }
                else
                {
                    vFailCount++;
                }
            }

            // Calculate class GPA
            if (vStudentCount > 0)
            {
                vClassGPA = vTotalGPA / vStudentCount;
            }

            // Display class information
            lblClassGPA.Text =
                "Class GPA: " + vClassGPA.ToString("F2") + "%";

            lblPassCount.Text =
                "Students Passed: " + vPassCount;

            lblFailCount.Text =
                "Students Failed: " + vFailCount;

            // Loop through each subject
            for (int vSubject = 0; vSubject < 6; vSubject++)
            {
                // Array to count letter grades
                int[] aGradeCounts = new int[6];

                double vTotalPercentage = 0;
                double vAverage = 0;

                // Loop through all students
                for (int vInd = 0; vInd < vStudentCount; vInd++)
                {
                    Student student = StudentData.Students[vInd];

                    // Retrieve subject percentage
                    double vPercentage = student.Percentages[vSubject];

                    // Add percentage to total
                    vTotalPercentage = vTotalPercentage + vPercentage;

                    // Retrieve letter grade
                    string vGrade = student.LetterGrades[vSubject];

                    // Count each letter grade
                    switch (vGrade)
                    {
                        case "A":
                            aGradeCounts[0]++;
                            break;

                        case "B":
                            aGradeCounts[1]++;
                            break;

                        case "C":
                            aGradeCounts[2]++;
                            break;

                        case "D":
                            aGradeCounts[3]++;
                            break;

                        case "E":
                            aGradeCounts[4]++;
                            break;

                        case "F":
                            aGradeCounts[5]++;
                            break;
                    }
                }

                // Calculate subject average
                if (vStudentCount > 0)
                {
                    vAverage = vTotalPercentage / vStudentCount;
                }

                // Create ListView item
                ListViewItem lvClassInfo = new ListViewItem();

                // Display subject name
                lvClassInfo.Text = StudentData.Subjects[vSubject];

                // Display class average
                lvClassInfo.SubItems.Add(vAverage.ToString("F2") + "%");

                // Display grade counts
                for (int vInd = 0; vInd < 6; vInd++)
                {
                    lvClassInfo.SubItems.Add(aGradeCounts[vInd].ToString());
                }

                // Add class information to ListView
                lvClassSummary.Items.Add(lvClassInfo);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
