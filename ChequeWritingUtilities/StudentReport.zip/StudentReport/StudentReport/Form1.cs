namespace StudentReport
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            // Reading student information from textboxes
            string firstName = txtFirstName.Text.Trim();
            string surname = txtSurname.Text.Trim();


            // Check that student names have been entered
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(surname))
            {
                MessageBox.Show("Please enter first name and surname.");
                return;
            }

            // Check the maximum number of students
            VerifyMaximumStudents();

            // Adding student names to the two-dimensional array
            AddStudents(firstName, surname);

            // Clear textboxes
            txtFirstName.Clear();
            txtSurname.Clear();
            // Set cursor back to first name textbox
            txtFirstName.Focus();
        }
        private void VerifyMaximumStudents()
        {
            if (StudentData.vx >= 100)
            {
                MessageBox.Show("Maximum 100 students allowed.");
                return;
            }
        }
        private void AddStudents(string firstName, string surname)
        {
            StudentData.aValues[StudentData.vx, 0] = firstName;
            StudentData.aValues[StudentData.vx, 1] = surname;

            // Create a new student object
            Student newStudent = new Student(firstName, surname);

            // Store student information
            StudentData.Students.Add(newStudent);

            // Adding student name and surname to ListBox
            lstStudents.Items.Add(firstName + " " + surname);

            // Increase student counter
            StudentData.vx++;

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (StudentData.vx < 10)
            {
                MessageBox.Show("Please enter at least 10 students.");
                return;
            }

            // Open Form 2
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }
    }
}
