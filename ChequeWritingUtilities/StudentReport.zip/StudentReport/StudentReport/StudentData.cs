﻿namespace StudentReport
{
    public static class StudentData
    {
        // Counter to store the number of students
        public static int vx = 0;

        // Two-dimensional array to store student names
        // Column 0 = First Name
        // Column 1 = Surname
        public static string[,] aValues = new string[100, 2];

        // Store student objects for Form 2 and Form 3
        public static List<Student> Students = new List<Student>();

        // Subject names
        public static string[] Subjects =
        {
            "Mathematics",
            "English",
            "History",
            "Geography",
            "Health and Physical Education",
            "Science"
        };

        // Maximum marks for each subject
        public static int[] MaximumMarks =
        {
            70, 70, 50, 50, 25, 50
        };

        // Multidimensional array to store marks
        public static int[,] ClassMarks = new int[100, 6];
    }
}
