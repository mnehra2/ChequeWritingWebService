﻿using System.Diagnostics;
using System.Drawing.Printing;


namespace StudentReport
{
    public partial class Form2 : Form
    {
        private PrintDocument printDocument = new PrintDocument();
        private int currentStudent = 0;
        private bool calculated = false;


        public Form2()
        {
            InitializeComponent();

            // this is to print the result
            printDocument.PrintPage += PrintDocument_PrintPage;
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            // Loop through the student array
            for (int vInd = 0; vInd < StudentData.vx; vInd++)
            {
                // Create a new ListViewItem
                ListViewItem lvCustInfo = new ListViewItem();

                // Retrieve student first name
                lvCustInfo.Text = StudentData.aValues[vInd, 0];

                // Add student surname as a subitem
                lvCustInfo.SubItems.Add(
                    StudentData.aValues[vInd, 1]);

                // Add student information to ListView
                lvStudents.Items.Add(lvCustInfo);
            }

            // call function to display students entered in form 1
            DisplayStudent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            Student student = StudentData.Students[currentStudent];

            // Read marks from textboxes
            string[] aMarks = { txtMaths.Text, txtEnglish.Text, txtHistory.Text, txtGeography.Text, txtHPE.Text, txtScience.Text };

            // variables for calculations
            int vMark;
            double vPercentage = 0;
            double vTotalPercentage = 0;

            // Clear previous results
            lvReport.Items.Clear();

            // Process all six subjects
            for (int vInd = 0; vInd < 6; vInd++)
            {
                // Convert textbox value into integer
                if (!int.TryParse(aMarks[vInd], out vMark))
                {
                    MessageBox.Show("Please enter valid marks for all subjects.");
                    return;
                }

                // Check that mark is within the subject maximum
                if (vMark < 0 || vMark > StudentData.MaximumMarks[vInd])
                {
                    MessageBox.Show("Invalid mark for " + StudentData.Subjects[vInd] + ". Maximum mark is " + StudentData.MaximumMarks[vInd]);
                    return;
                }

                // Store student mark in the array
                student.Marks[vInd] = vMark;

                // Store mark in the class multidimensional array
                StudentData.ClassMarks[currentStudent, vInd] = vMark;

                // Calculate percentage
                vPercentage = (double)vMark / StudentData.MaximumMarks[vInd] * 100;

                // Store percentage
                student.Percentages[vInd] = vPercentage;

                // Calculate letter grade
                string vGrade = CalculateGrade(vPercentage);

                student.LetterGrades[vInd] = vGrade;

                // Determine Pass or Fail
                string vResult;

                if (vPercentage < Constant.PassedMarks)
                {
                    vResult = "Fail";
                }
                else
                {
                    vResult = "Pass";
                }

                student.Results[vInd] = vResult;

                // Add percentage to total percentage
                vTotalPercentage = vTotalPercentage + vPercentage;

                // Create ListView item
                ListViewItem lvResult = new ListViewItem();

                // Display subject name
                lvResult.Text = StudentData.Subjects[vInd];

                // Display subject mark
                lvResult.SubItems.Add(vMark + " / " + StudentData.MaximumMarks[vInd]);

                // Display percentage
                lvResult.SubItems.Add(vPercentage.ToString("F2") + "%");

                // Display letter grade
                lvResult.SubItems.Add(vGrade);

                // Display Pass or Fail
                lvResult.SubItems.Add(vResult);

                // Add result to ListView
                lvReport.Items.Add(lvResult);
            }

            // Calculate final GPA
            student.GPA = vTotalPercentage / 6;

            // Calculate final letter grade
            student.FinalGrade = CalculateGrade(student.GPA);

            // Display final GPA
            lblGPA.Text = "Final GPA: " + student.GPA.ToString("F2") + "% - " + student.FinalGrade;

            // Check overall student result
            if (student.GPA < Constant.PassedMarks)
            {
                MessageBox.Show(student.FirstName + " " + student.Surname + ", has not passed the year.");
            }

            // Store that student results have been calculated
            student.HasResults = true;

            calculated = true;

            MessageBox.Show("Results calculated successfully.");
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (!calculated)
            {
                MessageBox.Show("Please calculate the current student's results first.");
                return;
            }

            // Check whether there is another student
            if (currentStudent < StudentData.Students.Count - 1)
            {
                currentStudent++;
                DisplayStudent();
            }
            else
            {
                MessageBox.Show("All students have been processed. " + "Click Class Summary to view class results.");
            }
        }

        private void btnClassSummary_Click(object sender, EventArgs e)
        {
            if (!calculated)
            {
                MessageBox.Show("Please calculate the current student's results first.");
                return;
            }

            // Check that every student has results
            foreach (Student student in StudentData.Students)
            {
                if (!student.HasResults)
                {
                    MessageBox.Show("Please enter results for all students first.");
                    return;
                }
            }

            Form3 form3 = new Form3();
            form3.Show();
        }
        private void DisplayStudent()
        {
            Student student = StudentData.Students[currentStudent];

            lblStudentName.Text = "Student: " + student.FirstName + " " + student.Surname;

            // Clear previous marks
            txtMaths.Clear();
            txtEnglish.Clear();
            txtHistory.Clear();
            txtGeography.Clear();
            txtHPE.Clear();
            txtScience.Clear();

            // Clear previous report
            lvReport.Items.Clear();
            lblGPA.Text = "Final GPA: ";
            calculated = false;
        }
        private double CalculatePercentage(int mark, int total)
        {
            return (double)mark / total * 100;
        }

        private string CalculateGrade(double percentage)
        {
            if (percentage >= 80)
                return "A";
            else if (percentage >= 65)
                return "B";
            else if (percentage >= 50)
                return "C";
            else if (percentage >= 35)
                return "D";
            else if (percentage >= 20)
                return "E";
            else
                return "F";
        }
        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (!calculated)
            {
                MessageBox.Show("Please calculate results first.");
                return;
            }

            PrintPreviewDialog preview = new PrintPreviewDialog();
            preview.Document = printDocument;
            preview.ShowDialog();
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Student student = StudentData.Students[currentStudent];

            Graphics g = e.Graphics;

            Font heading = new Font("Arial", 18, FontStyle.Bold);
            Font normal = new Font("Arial", 11);

            float y = 60;

            g.DrawString("STUDENT ACADEMIC REPORT", heading, Brushes.Black, 60, y);

            y += 50;

            g.DrawString("Student: " + student.FirstName + " " + student.Surname, normal, Brushes.Black, 60, y);

            y += 40;

            for (int i = 0; i < 6; i++)
            {
                string line = StudentData.Subjects[i] + " - " + student.Marks[i] + "/" + StudentData.MaximumMarks[i] + " - " + student.Percentages[i].ToString("F2") + "% - " + student.LetterGrades[i] + " - " + student.Results[i];
                g.DrawString(line, normal, Brushes.Black, 60, y);
                y += 30;
            }

            y += 20;

            g.DrawString("Final GPA: " + student.GPA.ToString("F2") + "% - " + student.FinalGrade, heading, Brushes.Black, 60, y);

            y += 50;

            if (student.GPA < Constant.PassedMarks)
            {
                g.DrawString(student.FirstName + " " + student.Surname + ", has not passed the year.", normal, Brushes.Black, 60, y);
            }
        }
    }
}
