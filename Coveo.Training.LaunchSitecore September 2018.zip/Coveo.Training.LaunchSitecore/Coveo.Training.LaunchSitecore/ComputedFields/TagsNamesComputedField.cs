﻿// Copyright (c) 2005-2018, Coveo Solutions Inc.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Coveo.Framework.CNL;
using Coveo.Framework.Databases;
using Coveo.Framework.Items;
using Coveo.Framework.Log;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Globalization;

namespace Coveo.Training.LaunchSitecore.ComputedFields
{
    public class TagsNamesComputedField : IComputedIndexField
    {
        private static readonly ILogger s_Logger = CoveoLogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private static readonly string[] s_SemanticsValueSeparators = { SEMANTICS_FIELD_VALUE_SEPARATOR };

        [ThreadStatic]
        private static IDatabaseWrapper s_Database;

        private const string SEMANTICS_FIELD_NAME = "__semantics";
        private const string SEMANTICS_FIELD_VALUE_SEPARATOR = "|";

        /// <inheritdoc />
        public string FieldName { get; set; }

        /// <inheritdoc />
        public string ReturnType
        {
            get
            {
                return "string";
            }
            set
            {
            }
        }

        /// <inheritdoc />
        public object ComputeFieldValue(IIndexable p_Indexable)
        {
            s_Logger.TraceEntering();
            Precondition.NotNull(p_Indexable, () => () => p_Indexable);

            IItem item = new ItemWrapper(new IndexableWrapper(p_Indexable));

            object value = GetItemTagsNames(item);

            s_Logger.TraceExiting();
            return value;
        }

        /// <summary>
        /// Gets the tags name from an <see cref="IItem"/>.
        /// </summary>
        /// <param name="p_Item">The item that is being indexed.</param>
        /// <returns>The tags name separated by a semicolon.</returns>
        private object GetItemTagsNames(IItem p_Item)
        {
            s_Logger.TraceEntering();
            Precondition.NotNull(p_Item, () => () => p_Item);
            s_Logger.Debug(p_Item.Uri.DataUri);

            s_Database = p_Item.Database;

            object tagsNames = null;
            IEnumerable<string> tagItemsIds = GetTagItemsIds(p_Item);
            if (tagItemsIds.Any()) {
                tagsNames = GetTagItemsNames(tagItemsIds, p_Item.Language);
            }

            s_Logger.Debug("Value: " + tagsNames);
            s_Logger.TraceExiting();
            return tagsNames;
        }

        private IEnumerable<string> GetTagItemsIds(IItem p_Item)
        {
            IEnumerable<string> tagItemsIds = new List<string>();
            string semanticsFieldValue = p_Item.GetFieldValue(SEMANTICS_FIELD_NAME);

            if (!String.IsNullOrEmpty(semanticsFieldValue)) {
                tagItemsIds = semanticsFieldValue.Split(s_SemanticsValueSeparators, StringSplitOptions.RemoveEmptyEntries);
            }
            return tagItemsIds;
        }

        private List<string> GetTagItemsNames(IEnumerable<string> p_TagItemsIds,
                                              Language p_SourceItemLanguage)
        {
            s_Logger.TraceEntering();

            List<string> tagsNames = new List<string>();
            foreach (string tagItemId in p_TagItemsIds) {
                string itemName = GetItemName(tagItemId, p_SourceItemLanguage);

                if (!String.IsNullOrEmpty(itemName)) {
                    tagsNames.Add(itemName);
                }
            }

            s_Logger.TraceExiting();

            return tagsNames.Any() ? tagsNames : null;
        }

        private string GetItemName(string p_Id,
                                   Language p_SourceItemLanguage)
        {
            string itemName = null;

            IItem item = ResolveReferencedItem(p_Id, p_SourceItemLanguage);
            if (item != null) {
                itemName = item.Name;
            }
            return itemName;
        }

        private IItem ResolveReferencedItem(string p_Id,
                                            Language p_SourceItemLanguage)
        {
            IItem item = s_Database.GetItem(p_Id, p_SourceItemLanguage);

            // When an item exists but doesn't for the requested language, Sitecore returns an
            // incomplete item. We must then verify if the item
            // has a version to know whether it is a real item or not.
            if (item == null || !item.Versions.HasVersion()) {
                item = s_Database.GetItem(p_Id);
            }

            return item;
        }
    }
}
