﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentReport
{
    public static class StudentData
    {
        public static List<Student> Students = new List<Student>();

        public static string[] Subjects =
        {
            "Mathematics",
            "English",
            "History",
            "Geography",
            "Health and Physical Education",
            "Science"
        };

        public static int[] MaximumMarks =
        {
            70, 70, 50, 50, 25, 50
        };

        // Multidimensional array:
        // Rows = students, Columns = subjects
        public static int[,] ClassMarks = new int[100, 6];
    }
}
