﻿using System.Diagnostics;
using System.Drawing.Printing;


namespace StudentReport
{
    public partial class Form2 : Form
    {
        private PrintDocument printDocument = new PrintDocument();
        private int currentStudent = 0;
        private bool calculated = false;
        

        public Form2()
        {
            InitializeComponent();

            // this is to print the result
            printDocument.PrintPage += PrintDocument_PrintPage;
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            // call function to display students entered in form 1
            DisplayStudent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            Student student = StudentData.Students[currentStudent];

            // Read marks from textboxes
            string[] enteredMarks = { txtMaths.Text, txtEnglish.Text, txtHistory.Text, txtGeography.Text, txtHPE.Text, txtScience.Text };

            // Clear previous results
            lvReport.Items.Clear();

            double totalPercentage = 0;

            // Process all six subjects
            for (int i = 0; i < 6; i++)
            {
                int mark;

                // Validate entered marks
                if (!int.TryParse(enteredMarks[i], out mark))
                {
                    MessageBox.Show("Please enter valid marks for all subjects.");
                    return;
                }

                // Check maximum mark
                if (mark < 0 || mark > StudentData.MaximumMarks[i])
                {
                    MessageBox.Show("Invalid mark for " + StudentData.Subjects[i] + ". Maximum mark is " + StudentData.MaximumMarks[i]);
                    return;
                }

                // Store mark
                student.Marks[i] = mark;

                StudentData.ClassMarks[currentStudent, i] = mark;

                // Calculate percentage
                double percentage = CalculatePercentage(mark, StudentData.MaximumMarks[i]);

                student.Percentages[i] = percentage;

                // Calculate letter grade
                string grade = CalculateGrade(percentage);

                student.LetterGrades[i] = grade;

                // Determine pass or fail
                string result = percentage < Constant.PassedMarks ? "Fail" : "Pass";

                student.Results[i] = result;

                // Add percentage to final GPA
                totalPercentage += percentage;

                // Display report in ListView
                ListViewItem item = new ListViewItem(StudentData.Subjects[i]);

                item.SubItems.Add(mark + " / " + StudentData.MaximumMarks[i]);
                item.SubItems.Add(percentage.ToString("F2") + "%");
                item.SubItems.Add(grade);
                item.SubItems.Add(result);
                lvReport.Items.Add(item);
            }

            // Calculate final GPA
            student.GPA = totalPercentage / 6;

            // Calculate final letter grade
            student.FinalGrade = CalculateGrade(student.GPA);

            // Display final GPA
            lblGPA.Text = "Final GPA: " + student.GPA.ToString("F2") + "% - " + student.FinalGrade;

            // Check overall result
            if (student.GPA < Constant.PassedMarks)
            {
                MessageBox.Show(student.FirstName + " " + student.Surname + ", has not passed the year.");
            }
            student.HasResults = true;
            calculated = true;
            MessageBox.Show("Results calculated successfully.");
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (!calculated)
            {
                MessageBox.Show("Please calculate the current student's results first.");
                return;
            }

            // Check whether there is another student
            if (currentStudent < StudentData.Students.Count - 1)
            {
                currentStudent++;
                DisplayStudent();
            }
            else
            {
                MessageBox.Show("All students have been processed. " + "Click Class Summary to view class results.");
            }
        }

        private void btnClassSummary_Click(object sender, EventArgs e)
        {
            if (!calculated)
            {
                MessageBox.Show("Please calculate the current student's results first.");
                return;
            }

            // Check that every student has results
            foreach (Student student in StudentData.Students)
            {
                if (!student.HasResults)
                {
                    MessageBox.Show("Please enter results for all students first.");
                    return;
                }
            }

            Form3 form3 = new Form3();
            form3.Show();
        }
        private void DisplayStudent()
        {
            Student student = StudentData.Students[currentStudent];

            lblStudentName.Text = "Student: " + student.FirstName + " " + student.Surname;

            // Clear previous marks
            txtMaths.Clear();
            txtEnglish.Clear();
            txtHistory.Clear();
            txtGeography.Clear();
            txtHPE.Clear();
            txtScience.Clear();

            // Clear previous report
            lvReport.Items.Clear();
            lblGPA.Text = "Final GPA: ";
            calculated = false;
        }
        private double CalculatePercentage(int mark, int total)
        {
            return (double)mark / total * 100;
        }

        private string CalculateGrade(double percentage)
        {
            if (percentage >= 80)
                return "A";
            else if (percentage >= 65)
                return "B";
            else if (percentage >= 50)
                return "C";
            else if (percentage >= 35)
                return "D";
            else if (percentage >= 20)
                return "E";
            else
                return "F";
        }
        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (!calculated)
            {
                MessageBox.Show("Please calculate results first.");
                return;
            }

            PrintPreviewDialog preview = new PrintPreviewDialog();
            preview.Document = printDocument;
            preview.ShowDialog();
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Student student = StudentData.Students[currentStudent];

            Graphics g = e.Graphics;

            Font heading = new Font("Arial", 18, FontStyle.Bold);
            Font normal = new Font("Arial", 11);

            float y = 60;

            g.DrawString("STUDENT ACADEMIC REPORT", heading, Brushes.Black, 60, y);

            y += 50;

            g.DrawString("Student: " + student.FirstName + " " + student.Surname, normal, Brushes.Black, 60, y);

            y += 40;

            for (int i = 0; i < 6; i++)
            {
                string line = StudentData.Subjects[i] + " - " + student.Marks[i] + "/" + StudentData.MaximumMarks[i] + " - " + student.Percentages[i].ToString("F2") + "% - " + student.LetterGrades[i] + " - " + student.Results[i];
                g.DrawString(line, normal, Brushes.Black, 60, y);
                y += 30;
            }

            y += 20;

            g.DrawString("Final GPA: " + student.GPA.ToString("F2") + "% - " + student.FinalGrade, heading, Brushes.Black, 60, y);

            y += 50;

            if (student.GPA < Constant.PassedMarks)
            {
                g.DrawString(student.FirstName + " " + student.Surname + ", has not passed the year.", normal, Brushes.Black, 60, y);
            }
        }
    }
}
