﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentReport
{
    internal class Constant
    {
        internal const int PassedMarks = 35;
    }
}
