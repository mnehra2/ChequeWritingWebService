namespace StudentReport
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            string firstName = txtFirstName.Text.Trim();
            string surname = txtSurname.Text.Trim();

            // Check that both names have been entered
            if (firstName == "" || surname == "")
            {
                MessageBox.Show("Please enter first name and surname.");
                return;
            }

            // Check the maximum number of students
            if (StudentData.Students.Count >= 100)
            {
                MessageBox.Show("Maximum 100 students allowed.");
                return;
            }

            // Create a new student object
            Student newStudent = new Student(firstName, surname);

            // Store student information
            StudentData.Students.Add(newStudent);

            // Display student in ListBox
            lstStudents.Items.Add(firstName + " " + surname);

            // Clear textboxes
            txtFirstName.Clear();
            txtSurname.Clear();

            txtFirstName.Focus();

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (StudentData.Students.Count < 10)
            {
                MessageBox.Show(
                    "Please enter at least 10 students.");
                return;
            }

            // Open Form 2
            Form2 form2 = new Form2();

            form2.Show();

            this.Hide();
        }
    }
}
