﻿namespace StudentReport
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblClassGPA = new Label();
            lblStudentCount = new Label();
            lblPassCount = new Label();
            lblFailCount = new Label();
            lvClassSummary = new ListView();
            Subject = new ColumnHeader();
            ClassAverage = new ColumnHeader();
            ACount = new ColumnHeader();
            BCount = new ColumnHeader();
            CCount = new ColumnHeader();
            DCount = new ColumnHeader();
            ECount = new ColumnHeader();
            FCount = new ColumnHeader();
            btnClose = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Location = new Point(201, 47);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(175, 25);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Class Data Summary";
            // 
            // lblClassGPA
            // 
            lblClassGPA.AutoSize = true;
            lblClassGPA.Location = new Point(201, 87);
            lblClassGPA.Name = "lblClassGPA";
            lblClassGPA.Size = new Size(90, 25);
            lblClassGPA.TabIndex = 1;
            lblClassGPA.Text = "Class GPA";
            // 
            // lblStudentCount
            // 
            lblStudentCount.AutoSize = true;
            lblStudentCount.Location = new Point(201, 130);
            lblStudentCount.Name = "lblStudentCount";
            lblStudentCount.Size = new Size(123, 25);
            lblStudentCount.TabIndex = 2;
            lblStudentCount.Text = "Total Students";
            // 
            // lblPassCount
            // 
            lblPassCount.AutoSize = true;
            lblPassCount.Location = new Point(201, 179);
            lblPassCount.Name = "lblPassCount";
            lblPassCount.Size = new Size(140, 25);
            lblPassCount.TabIndex = 3;
            lblPassCount.Text = "Students Passed";
            // 
            // lblFailCount
            // 
            lblFailCount.AutoSize = true;
            lblFailCount.Location = new Point(201, 226);
            lblFailCount.Name = "lblFailCount";
            lblFailCount.Size = new Size(131, 25);
            lblFailCount.TabIndex = 4;
            lblFailCount.Text = "Students Failed";
            // 
            // lvClassSummary
            // 
            lvClassSummary.Columns.AddRange(new ColumnHeader[] { Subject, ClassAverage, ACount, BCount, CCount, DCount, ECount, FCount });
            lvClassSummary.FullRowSelect = true;
            lvClassSummary.GridLines = true;
            lvClassSummary.Location = new Point(71, 285);
            lvClassSummary.Name = "lvClassSummary";
            lvClassSummary.Size = new Size(650, 168);
            lvClassSummary.TabIndex = 5;
            lvClassSummary.UseCompatibleStateImageBehavior = false;
            lvClassSummary.View = View.Details;
            // 
            // Subject
            // 
            Subject.Text = "Subject";
            // 
            // ClassAverage
            // 
            ClassAverage.Text = "Class Average %";
            // 
            // ACount
            // 
            ACount.Text = "A Count";
            // 
            // BCount
            // 
            BCount.Text = "B Count";
            // 
            // CCount
            // 
            CCount.Text = "C Count";
            // 
            // DCount
            // 
            DCount.Text = "D Count";
            // 
            // ECount
            // 
            ECount.Text = "E Count";
            // 
            // FCount
            // 
            FCount.Text = "F Count";
            // 
            // btnClose
            // 
            btnClose.Location = new Point(128, 459);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(112, 34);
            btnClose.TabIndex = 6;
            btnClose.Text = "Close";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += btnClose_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo;
            pictureBox1.Location = new Point(25, 37);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(150, 75);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(979, 608);
            Controls.Add(pictureBox1);
            Controls.Add(btnClose);
            Controls.Add(lvClassSummary);
            Controls.Add(lblFailCount);
            Controls.Add(lblPassCount);
            Controls.Add(lblStudentCount);
            Controls.Add(lblClassGPA);
            Controls.Add(lblTitle);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblClassGPA;
        private Label lblStudentCount;
        private Label lblPassCount;
        private Label lblFailCount;
        private ListView lvClassSummary;
        private ColumnHeader Subject;
        private ColumnHeader ClassAverage;
        private ColumnHeader ACount;
        private ColumnHeader BCount;
        private ColumnHeader CCount;
        private ColumnHeader DCount;
        private ColumnHeader ECount;
        private ColumnHeader FCount;
        private Button btnClose;
        private PictureBox pictureBox1;
    }
}