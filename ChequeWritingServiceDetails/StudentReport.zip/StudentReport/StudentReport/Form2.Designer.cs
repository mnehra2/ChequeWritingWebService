﻿namespace StudentReport
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblStudentName = new Label();
            txtMaths = new TextBox();
            txtEnglish = new TextBox();
            txtHistory = new TextBox();
            txtGeography = new TextBox();
            txtHPE = new TextBox();
            txtScience = new TextBox();
            lblMaths = new Label();
            lblEnglish = new Label();
            lblHistory = new Label();
            lblGeography = new Label();
            lblHPE = new Label();
            lblScience = new Label();
            btnCalculate = new Button();
            btnNext = new Button();
            btnClassSummary = new Button();
            lvReport = new ListView();
            Subject = new ColumnHeader();
            Mark = new ColumnHeader();
            Percentage = new ColumnHeader();
            LetterGrade = new ColumnHeader();
            Result = new ColumnHeader();
            lblGPA = new Label();
            btnPrint = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Location = new Point(254, 25);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(213, 25);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Student Academic Report";
            // 
            // lblStudentName
            // 
            lblStudentName.AutoSize = true;
            lblStudentName.Location = new Point(604, 25);
            lblStudentName.Name = "lblStudentName";
            lblStudentName.Size = new Size(125, 25);
            lblStudentName.TabIndex = 1;
            lblStudentName.Text = "Student Name";
            // 
            // txtMaths
            // 
            txtMaths.Location = new Point(444, 79);
            txtMaths.Name = "txtMaths";
            txtMaths.Size = new Size(150, 31);
            txtMaths.TabIndex = 2;
            // 
            // txtEnglish
            // 
            txtEnglish.Location = new Point(444, 132);
            txtEnglish.Name = "txtEnglish";
            txtEnglish.Size = new Size(150, 31);
            txtEnglish.TabIndex = 3;
            // 
            // txtHistory
            // 
            txtHistory.Location = new Point(444, 169);
            txtHistory.Name = "txtHistory";
            txtHistory.Size = new Size(150, 31);
            txtHistory.TabIndex = 4;
            // 
            // txtGeography
            // 
            txtGeography.Location = new Point(444, 224);
            txtGeography.Name = "txtGeography";
            txtGeography.Size = new Size(150, 31);
            txtGeography.TabIndex = 5;
            // 
            // txtHPE
            // 
            txtHPE.Location = new Point(444, 287);
            txtHPE.Name = "txtHPE";
            txtHPE.Size = new Size(150, 31);
            txtHPE.TabIndex = 6;
            // 
            // txtScience
            // 
            txtScience.Location = new Point(444, 346);
            txtScience.Name = "txtScience";
            txtScience.Size = new Size(150, 31);
            txtScience.TabIndex = 7;
            // 
            // lblMaths
            // 
            lblMaths.AutoSize = true;
            lblMaths.Location = new Point(254, 79);
            lblMaths.Name = "lblMaths";
            lblMaths.Size = new Size(150, 25);
            lblMaths.TabIndex = 8;
            lblMaths.Text = "Mathematics / 70";
            // 
            // lblEnglish
            // 
            lblEnglish.AutoSize = true;
            lblEnglish.Location = new Point(301, 132);
            lblEnglish.Name = "lblEnglish";
            lblEnglish.Size = new Size(105, 25);
            lblEnglish.TabIndex = 9;
            lblEnglish.Text = "English / 70";
            // 
            // lblHistory
            // 
            lblHistory.AutoSize = true;
            lblHistory.Location = new Point(301, 172);
            lblHistory.Name = "lblHistory";
            lblHistory.Size = new Size(106, 25);
            lblHistory.TabIndex = 10;
            lblHistory.Text = "History / 50";
            // 
            // lblGeography
            // 
            lblGeography.AutoSize = true;
            lblGeography.Location = new Point(284, 227);
            lblGeography.Name = "lblGeography";
            lblGeography.Size = new Size(137, 25);
            lblGeography.TabIndex = 11;
            lblGeography.Text = "Geography / 50";
            // 
            // lblHPE
            // 
            lblHPE.AutoSize = true;
            lblHPE.Location = new Point(301, 290);
            lblHPE.Name = "lblHPE";
            lblHPE.Size = new Size(81, 25);
            lblHPE.TabIndex = 12;
            lblHPE.Text = "HPE / 25";
            // 
            // lblScience
            // 
            lblScience.AutoSize = true;
            lblScience.Location = new Point(301, 352);
            lblScience.Name = "lblScience";
            lblScience.Size = new Size(107, 25);
            lblScience.TabIndex = 13;
            lblScience.Text = "Science / 50";
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(301, 427);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(112, 34);
            btnCalculate.TabIndex = 14;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // btnNext
            // 
            btnNext.Location = new Point(522, 427);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(187, 34);
            btnNext.TabIndex = 15;
            btnNext.Text = "Next Student";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click;
            // 
            // btnClassSummary
            // 
            btnClassSummary.Location = new Point(745, 427);
            btnClassSummary.Name = "btnClassSummary";
            btnClassSummary.Size = new Size(196, 34);
            btnClassSummary.TabIndex = 16;
            btnClassSummary.Text = "Class Summary";
            btnClassSummary.UseVisualStyleBackColor = true;
            btnClassSummary.Click += btnClassSummary_Click;
            // 
            // lvReport
            // 
            lvReport.Columns.AddRange(new ColumnHeader[] { Subject, Mark, Percentage, LetterGrade, Result });
            lvReport.FullRowSelect = true;
            lvReport.GridLines = true;
            lvReport.Location = new Point(412, 477);
            lvReport.MultiSelect = false;
            lvReport.Name = "lvReport";
            lvReport.Size = new Size(467, 211);
            lvReport.TabIndex = 17;
            lvReport.UseCompatibleStateImageBehavior = false;
            lvReport.View = View.Details;
            // 
            // Subject
            // 
            Subject.Text = "Subject";
            // 
            // Mark
            // 
            Mark.Text = "Mark";
            // 
            // Percentage
            // 
            Percentage.Text = "Percentage";
            // 
            // LetterGrade
            // 
            LetterGrade.Text = "Letter Grade";
            // 
            // Result
            // 
            Result.Text = "Result";
            // 
            // lblGPA
            // 
            lblGPA.AutoSize = true;
            lblGPA.Location = new Point(229, 515);
            lblGPA.Name = "lblGPA";
            lblGPA.Size = new Size(86, 25);
            lblGPA.TabIndex = 18;
            lblGPA.Text = "Final GPA";
            // 
            // btnPrint
            // 
            btnPrint.Location = new Point(960, 653);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(112, 34);
            btnPrint.TabIndex = 19;
            btnPrint.Text = "Print Report";
            btnPrint.UseVisualStyleBackColor = true;
            btnPrint.Click += btnPrint_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo;
            pictureBox1.Location = new Point(45, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(150, 75);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 20;
            pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1104, 700);
            Controls.Add(pictureBox1);
            Controls.Add(btnPrint);
            Controls.Add(lblGPA);
            Controls.Add(lvReport);
            Controls.Add(btnClassSummary);
            Controls.Add(btnNext);
            Controls.Add(btnCalculate);
            Controls.Add(lblScience);
            Controls.Add(lblHPE);
            Controls.Add(lblGeography);
            Controls.Add(lblHistory);
            Controls.Add(lblEnglish);
            Controls.Add(lblMaths);
            Controls.Add(txtScience);
            Controls.Add(txtHPE);
            Controls.Add(txtGeography);
            Controls.Add(txtHistory);
            Controls.Add(txtEnglish);
            Controls.Add(txtMaths);
            Controls.Add(lblStudentName);
            Controls.Add(lblTitle);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblStudentName;
        private TextBox txtMaths;
        private TextBox txtEnglish;
        private TextBox txtHistory;
        private TextBox txtGeography;
        private TextBox txtHPE;
        private TextBox txtScience;
        private Label lblMaths;
        private Label lblEnglish;
        private Label lblHistory;
        private Label lblGeography;
        private Label lblHPE;
        private Label lblScience;
        private Button btnCalculate;
        private Button btnNext;
        private Button btnClassSummary;
        private ListView lvReport;
        private ColumnHeader Subject;
        private ColumnHeader Mark;
        private ColumnHeader Percentage;
        private ColumnHeader LetterGrade;
        private ColumnHeader Result;
        private Label lblGPA;
        private Button btnPrint;
        private PictureBox pictureBox1;
    }
}