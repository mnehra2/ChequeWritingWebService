﻿using System;
using System.Collections.Generic;

namespace StudentReport
{
    public class Student
    {
        public string FirstName { get; set; }
        public string Surname { get; set; }

        public int[] Marks = new int[6];

        public double[] Percentages = new double[6];

        public string[] LetterGrades = new string[6];

        public string[] Results = new string[6];

        public double GPA { get; set; }
        public bool HasResults { get; set; } = false;
        public string FinalGrade { get; set; }
        public Student(string firstName, string surname)
        {
            FirstName = firstName;
            Surname = surname;
        }

    }
}
