﻿namespace StudentReport
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblFirstName = new Label();
            txtFirstName = new TextBox();
            lblSurname = new Label();
            txtSurname = new TextBox();
            btnAddStudent = new Button();
            lstStudents = new ListBox();
            btnStart = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Location = new Point(403, 47);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(172, 25);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Student Registration";
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Location = new Point(259, 125);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(97, 25);
            lblFirstName.TabIndex = 1;
            lblFirstName.Text = "First Name";
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(519, 125);
            txtFirstName.MaxLength = 50;
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(150, 31);
            txtFirstName.TabIndex = 2;
            // 
            // lblSurname
            // 
            lblSurname.AutoSize = true;
            lblSurname.Location = new Point(259, 179);
            lblSurname.Name = "lblSurname";
            lblSurname.Size = new Size(82, 25);
            lblSurname.TabIndex = 3;
            lblSurname.Text = "Surname";
            // 
            // txtSurname
            // 
            txtSurname.Location = new Point(519, 173);
            txtSurname.MaxLength = 50;
            txtSurname.Name = "txtSurname";
            txtSurname.Size = new Size(150, 31);
            txtSurname.TabIndex = 4;
            // 
            // btnAddStudent
            // 
            btnAddStudent.Location = new Point(420, 242);
            btnAddStudent.Name = "btnAddStudent";
            btnAddStudent.Size = new Size(176, 34);
            btnAddStudent.TabIndex = 5;
            btnAddStudent.Text = "Add Student";
            btnAddStudent.UseVisualStyleBackColor = true;
            btnAddStudent.Click += btnAddStudent_Click;
            // 
            // lstStudents
            // 
            lstStudents.FormattingEnabled = true;
            lstStudents.Location = new Point(232, 315);
            lstStudents.Name = "lstStudents";
            lstStudents.Size = new Size(530, 129);
            lstStudents.TabIndex = 6;
            // 
            // btnStart
            // 
            btnStart.Location = new Point(395, 465);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(180, 34);
            btnStart.TabIndex = 7;
            btnStart.Text = "Enter Results";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo;
            pictureBox1.Location = new Point(156, 32);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(150, 75);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1042, 511);
            Controls.Add(pictureBox1);
            Controls.Add(btnStart);
            Controls.Add(lstStudents);
            Controls.Add(btnAddStudent);
            Controls.Add(txtSurname);
            Controls.Add(lblSurname);
            Controls.Add(txtFirstName);
            Controls.Add(lblFirstName);
            Controls.Add(lblTitle);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblFirstName;
        private TextBox txtFirstName;
        private Label lblSurname;
        private TextBox txtSurname;
        private Button btnAddStudent;
        private ListBox lstStudents;
        private Button btnStart;
        private PictureBox pictureBox1;
    }
}
