﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentReport
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            int numberOfStudents =
        StudentData.Students.Count;

            double totalGPA = 0;

            int passCount = 0;
            int failCount = 0;

            // Display number of students
            lblStudentCount.Text =
                "Total Students: " + numberOfStudents;

            // Process each student
            foreach (Student student in StudentData.Students)
            {
                totalGPA += student.GPA;

                if (student.GPA >= 35)
                    passCount++;
                else
                    failCount++;
            }

            // Calculate class GPA
            double classGPA =
                totalGPA / numberOfStudents;

            lblClassGPA.Text =
                "Class GPA: " +
                classGPA.ToString("F2") + "%";

            lblPassCount.Text =
                "Students Passed: " + passCount;

            lblFailCount.Text =
                "Students Failed: " + failCount;

            // Calculate subject statistics
            for (int subject = 0; subject < 6; subject++)
            {
                int[] gradeCounts = new int[6];

                double totalPercentage = 0;

                // Process every student
                for (int studentIndex = 0;
                     studentIndex < numberOfStudents;
                     studentIndex++)
                {
                    Student student =
                        StudentData.Students[studentIndex];

                    double percentage =
                        student.Percentages[subject];

                    totalPercentage += percentage;

                    string grade =
                        student.LetterGrades[subject];

                    // Count each letter grade
                    switch (grade)
                    {
                        case "A":
                            gradeCounts[0]++;
                            break;

                        case "B":
                            gradeCounts[1]++;
                            break;

                        case "C":
                            gradeCounts[2]++;
                            break;

                        case "D":
                            gradeCounts[3]++;
                            break;

                        case "E":
                            gradeCounts[4]++;
                            break;

                        case "F":
                            gradeCounts[5]++;
                            break;
                    }
                }

                // Calculate subject class average
                double average =
                    totalPercentage / numberOfStudents;

                // Display subject summary
                ListViewItem item = new ListViewItem(
                    StudentData.Subjects[subject]);

                item.SubItems.Add(
                    average.ToString("F2") + "%");

                for (int i = 0; i < 6; i++)
                {
                    item.SubItems.Add(
                        gradeCounts[i].ToString());
                }

                lvClassSummary.Items.Add(item);
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
