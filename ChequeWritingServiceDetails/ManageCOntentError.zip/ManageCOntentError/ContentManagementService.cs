﻿using Ablis.Api.Application.Interfaces;
using Ablis.Api.Domain;
using Ablis.Api.Domain.Models;
using Ablis.Api.Domain.Models.ServiceTasksModels;
using Bga.Sc.Foundation.AuditTrail.Helper;
using Bga.Sc.Foundation.DependencyInjection;
using Bga.Sc.Foundation.SitecoreExtensions.Enums;
using Bga.Sc.Foundation.SitecoreExtensions.Extensions;
using Bga.Sc.Foundation.SitecoreExtensions.Helpers;
using Bga.Sc.Foundation.SitecoreExtensions.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.ServiceModel;

namespace Ablis.Api.Application.Services
{
    [Service(Lifetime = Lifetime.Transient, ServiceType = typeof(IContentManagementService))]
    public class ContentManagementService : IContentManagementService
    {
        private readonly ILogger _logger;
        private readonly IHandlerFactory _handlerFactory;

        public ContentManagementService(ILogger logger, IHandlerFactory handlerFactory)
        {
            _logger = logger;
            _handlerFactory = handlerFactory;
        }
        public ManageEntitiesResponse ManageEntities(ManageEntitiesRequest request)
        {
            try
            {
                if (request == null || request.RequestItem == null)
                {
                    throw new NotSupportedException("ManageEntities() error. Request must not be null.");
                }
                var responses = new List<ManageEntitiesResponseResponseItem>();
                foreach (var item in request.RequestItem)
                {
                    var handler = _handlerFactory.CreateHandler(item.Type);

                    var response = handler.Process(_handlerFactory.Handlers, handler, item.Id, item.Type, item.Action, request.Jurisdiction);
                    responses.Add(
                                new ManageEntitiesResponseResponseItem()
                                {
                                    Id = item.Id,
                                    IsSuccess = response.IsSuccessful,
                                    Error = handler.GetErrors().Select(
                                        x => new Error { Code = String.Format("{0} Error Code {1}", item.Action, x.Code), Description = x.Description }
                                    ).ToArray()
                                }
                            );
                }

                return new ManageEntitiesResponse()
                {
                    // CorrelationId = AblisTrace.GetCorrelationId().ToString(),
                    ResponseItem = responses.ToArray()
                };
            }
            catch (Exception ex)
            {
                return new ManageEntitiesResponse()
                {
                    // CorrelationId = AblisTrace.GetCorrelationId().ToString(),
                    ResponseItem = null
                };
            }
        }

        public ManageContentResponse ManageContent(ManageContentRequest request)
        {
            EntityType type;
            string typeId = string.Empty;
            var responses = new List<ManageContentResponseResponseItem>();

            try
            {
                if (request == null || request.RequestItem == null)
                {
                    throw new NotSupportedException("ManageContent() error. Request must not be null.");
                }
                // validate against the schema and return any errors as a fault
                var errors = request.Validate();
                if (errors.Length > 0)
                    throw new FaultException($"Error 1002:{Environment.NewLine}" + string.Join(Environment.NewLine, errors));

                //Get all the servicetasks in the request, and the serviceId
                // Get the Services external id				
                try
                {
                    var serviceTasks = new List<string>();
                    var itm = request.RequestItem.Where(a => a.Item.Item.GetType() == typeof(Service))?.FirstOrDefault();
                    if (itm != null)
                    {
                        var actionId = itm.ActionId;
                        var ritm = request.RequestItem.Where(a => a.ActionId == actionId)?.FirstOrDefault();
                        var sItem = (Service)ritm.Item.Item;

                        // Get the ServiceTasks
                        foreach (var item in request.RequestItem.Where(a => a.Item.Item.GetType() == typeof(ServiceTask)))
                        {
                            var stItem = (ServiceTask)item.Item.Item;
                            if (!string.IsNullOrEmpty(stItem.Id.ExternalId))
                            {
                                serviceTasks.Add(stItem.Id.ExternalId);
                            }
                        }
                        if (serviceTasks.Count > 0)
                        {
                            // If we have any then check if they should be deleted
                            // get the handler related to Servicetasks
                            var handler = _handlerFactory.CreateHandler(EntityType.ServiceTask);

                            // process the handler to check the servicetasks
                            if (handler.DeleteRemovedServiceTasks(_handlerFactory.Handlers, handler, serviceTasks, sItem.Id, request.Jurisdiction.ToString()))
                            {
                                Logger.LogInfo("Service tasks deleted successfully for service" + sItem.Id);
                            }
                        }
                    }
                }

                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                    throw new FaultException("Error int.Parse(Constants.UnexpectedErrorCode) : Unexpected error" + ex + ex.Message);
                }

                var itemsInAllRequests = new List<ItemMappingModel>();
                foreach (var item in request.RequestItem)
                {
                    type = item.Item.Item.GetType().Name.ToEnum<EntityType>();
                    if (type == EntityType.Service || type == EntityType.Document)
                    {
                        // do the work as part of service pbi
                    }

                    var handler = _handlerFactory.CreateHandler(type);
                    handler.SetItemList(itemsInAllRequests);
                    var ablisId = handler.GetItemAblisId(item.Item.Item);
                    var response = handler.ManageContent(_handlerFactory.Handlers, handler, type, ablisId, item.Item.Item, request.Jurisdiction, out List<ItemMappingModel> itemsCreatedInRequests);

                    // each request item has a corresponding response item
                    responses.Add(
                        new ManageContentResponseResponseItem
                        {
                            ActionId = item.ActionId,
                            Id = response.Id,
                            IsSuccess = response.IsSuccessful,
                            ParentEntity = response,
                            Error = handler.GetErrors().Select(
                                        x => new Error { Code = "HandlerError" + x.Code, Description = x.Description }
                                    ).ToArray()
                        }
                    );
                    itemsInAllRequests = itemsCreatedInRequests;
                }

                var emailItemsList = itemsInAllRequests?.Where(x => x.SendEmailNotification);

                if (emailItemsList != null && emailItemsList.Any())
                {
                    SendApprovalEmail(emailItemsList.ToList());
                }
                return new ManageContentResponse
                {
                    ResponseItem = responses.ToArray()
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw new FaultException("Error 9000 : Unexpected error" + ex + ex.Message);
            }
        }
        private void SendApprovalEmail(List<ItemMappingModel> emailItemList)
        {
            var item = BgaItemExtensions.GetItemById(Constants.AblisToolConfigurationItem);
            var sendEmail = item[Templates.ToolConfiguration.Fields.ApiChangesEmailAddress];
            var emailTemplate = item[Templates.ToolConfiguration.Fields.ApiChangesEmailTemplate];

            var approvalEmailTemplate = GetApprovalEmailTemplate(emailItemList, emailTemplate);

            if (!string.IsNullOrEmpty(sendEmail) && !string.IsNullOrEmpty(emailTemplate) && ConfigurationManager.AppSettings["role:define"] != "Standalone")
                EmailHelper.SendEmail(sendEmail, string.Empty, string.Empty, approvalEmailTemplate.EmailSubject, approvalEmailTemplate.EmailBodyLayout, true, site: SiteName.ABLIS);
        }

        private SharedEmailTemplateModel GetApprovalEmailTemplate(List<ItemMappingModel> emailItemList, string emailTemplate)
        {

            var emailTemplateItem = BgaItemExtensions.GetItemById(emailTemplate);
            var template = EmailHelper.GetEmailTemplate(emailTemplateItem);
            string emailListHtml = "";
            
            foreach (var item in emailItemList)
            {
                var outputLayout = emailTemplateItem[Bga.Sc.Foundation.SitecoreExtensions.Templates.HtmlEmailParams.Fields.EmailToolOutputBody];
                if (!string.IsNullOrEmpty(outputLayout))
                {
                    var id = !string.IsNullOrEmpty(item.ExternalId) ? item.ExternalId : item.InternalId;
                    outputLayout = outputLayout.Replace(Constants.EntityTypeLabelToken, item.Type.ToString());
                    outputLayout = outputLayout.Replace(Constants.TextToken, item.Text);
                    outputLayout = outputLayout.Replace(Constants.IdToken, id);
                    emailListHtml += outputLayout;
                }
            }

            template.EmailBodyLayout = template.EmailBodyLayout.Replace(Constants.EmailToken, emailListHtml);
            return template;
        }
    }
}