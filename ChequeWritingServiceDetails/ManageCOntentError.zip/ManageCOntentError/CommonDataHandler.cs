﻿using Ablis.Api.Application.Interfaces;
using Ablis.Api.Domain;
using Ablis.Api.Domain.Interfaces;
using Ablis.Api.Domain.Models;
using Ablis.Api.Domain.Models.AddressModels;
using Ablis.Api.Domain.Models.ContactModels;
using Ablis.Api.Domain.Models.GeographicPolygonModels;
using Ablis.Api.Domain.Models.OrganisationModels;
using Ablis.Api.Domain.Models.ServiceTasksModels;
using Bga.Sc.Foundation.AuditTrail.Helper;
using Bga.Sc.Foundation.SitecoreExtensions.Extensions;
using Bga.Sc.Foundation.SitecoreExtensions.Utilities;
using Sitecore;
using Sitecore.Buckets.Managers;
using Sitecore.Configuration;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq.Utilities;
using Sitecore.ContentSearch.Maintenance;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Security.Accounts;
using Sitecore.Workflows;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Ablis.Api.Application.Handlers
{
    public abstract class CommonDataHandler<TModelType> : IHandler where TModelType : class, ICommonDataEntity, new()
    {
        protected readonly ILogger _logger;

        protected CommonDataHandler(ILogger logger)
        {
            _logger = logger;
        }

        public abstract EntityType HandledType { get; }

        /// <summary>
        /// AblisId of this item
        /// </summary>
        public AblisId AblisId { get; set; }


        /// <summary>
        /// Service request / response item
        /// </summary>
        public TModelType RequestItem { get; set; }

        /// <summary>
        /// Errors
        /// </summary>
        public List<(int Code, string Description)> Errors = new List<(int Code, string Description)>();

        public List<ItemMappingModel> ItemsCreatedInRequest = new List<ItemMappingModel>();

        public bool IsRoot { get; set; }

        /// <summary>
        /// Some handlers need this to parse un-supported html tags
        /// </summary>
        public HtmlSnippetParser HtmlParser = new HtmlSnippetParser("a,abbr,acronym,address,b,blockquote,br,cite,code,dd,dfn,dl,dt,em,h1,h2,h3,h4,h5,h6,i,li,ol,p,quote,strong,sub,sup,ul");

        private List<IHandler> Children { get; set; } // for commit, rollback
        protected CommonDataHandler()
        {
            this.Initialize();
        }

        /// <summary>
        /// Create a new instance with a requestItem service object
        /// </summary>
        /// <param name="requestItem"></param>
        protected CommonDataHandler(TModelType requestItem)
        {
            this.Initialize();
            this.RequestItem = requestItem;
            this.AblisId = this.RequestItem.Id;
        }

        private const int batchSize = 20;

        private void Initialize()
        {
            this.Children = new List<IHandler>();
            this.Errors = new List<(int Code, string Description)>();
        }
        internal EntityResponse Response { get; set; }
        public AblisId GetAblisId(Item item)
        {
            return new AblisId()
            {
                ExternalId = item[Templates.AblisId.Fields.ExternalId],
                InternalId = item[Templates.AblisId.Fields.InternalId],
                InternalGuid = Guid.TryParse(item[Templates.AblisId.Fields.InternalId], out Guid result) ? result : Guid.Empty
            };
        }
        public CommonDataPublishedStatus GetCommonDataStatus(Item item)
        {
            var approvedItem = GetLastApprovedVersion(item);
            var commonDataStatus = new CommonDataPublishedStatus
            {
                LastPublishedLiveBy = approvedItem != null ? approvedItem.Statistics.UpdatedBy : string.Empty,
                PublishedState = GetWorkflowStatus(item).ToString()
            };

            if (approvedItem != null && approvedItem.Statistics.Updated > DateTime.MinValue)
            {
                commonDataStatus.LastPublishedLiveDate = approvedItem.Statistics.Updated;
                commonDataStatus.LastPublishedLiveDateSpecified = true;
            }
            return commonDataStatus;
        }

        public EntityStatus? GetWorkflowStatus(Item item)
        {
            if (item[FieldIDs.WorkflowState] == Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowDraftState)
                return EntityStatus.Draft;

            else if (item[FieldIDs.WorkflowState] == Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowAwaitingApprovalState)
                return EntityStatus.Pending;

            else if (item[FieldIDs.WorkflowState] == Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowApprovedState)
                return EntityStatus.Approved;

            else if (item[FieldIDs.WorkflowState] == Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowDeletionState)
                return EntityStatus.Deleted;

            return null;

        }

        public PublishedDataStatus GetPublishedDataStatus(Item item)
        {
            var approvedItem = GetLastApprovedVersion(item);
            // need to add more properties later
            var publishedDataStatus = new PublishedDataStatus
            {
                LastPublishedLiveBy = approvedItem != null ? approvedItem.Statistics.UpdatedBy : string.Empty,
                PublishedState = GetWorkflowStatus(item).ToString()
            };

            if (approvedItem != null && approvedItem.Statistics.Updated > DateTime.MinValue)
            {
                publishedDataStatus.LastPublishedLiveDate = approvedItem.Statistics.Updated;
                publishedDataStatus.LastPublishedLiveDateSpecified = true;
            }
            return publishedDataStatus;
        }
        public void PushItemToIndex(Item item)
        {
            IIndexableUniqueId indexableUniqueId = new SitecoreItemUniqueId(item.Uri);
            ISearchIndex masterIndex = ContentSearchManager.GetIndex("sitecore_master_index");

            if (masterIndex != null)
            {
                // Force an immediate indexing of the item straight away
                IndexCustodian.UpdateItem(masterIndex, indexableUniqueId);
            }
        }
        public void Publish(Item item, bool publishSubItems = false)
        {
            item = item.Versions.GetLatestVersion();
            item.Editing.BeginEdit();
            item[FieldIDs.WorkflowState] = Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowApprovedState;
            RemoveUnpublishDate(item);
            item.Editing.EndEdit();
            if (BucketManager.IsBucket(item))
                PublishBucketItem(item, publishSubItems);
            else
                PublishExtensions.PublishItem(item, publishSubItems);
        }

        public void UpdateDescendantWorkflow(Item parentItem)
        {
            var descendants = parentItem?.Axes.GetDescendants()?.ToList();
            if (descendants != null && descendants.Any())
            {
                foreach (Item descendant in descendants)
                {
                    var item = descendant.Versions.GetLatestVersion();
                    if (DisplayExtensions.ItemNotInDeletionApprovalWorkflowState(item))
                    {
                        item.Editing.BeginEdit();
                        item[FieldIDs.WorkflowState] = Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowApprovedState;
                        item.Editing.EndEdit();
                    }
                }
            }
        }

        private void PublishBucketItem(Item targetItem, bool publishSubItems)
        {
            if (targetItem == null) return;

            // 1. Collect the item and up to 3 parents going upwards
            var itemsToPublish = new List<Item> { targetItem };
            Item currentParent = targetItem.Parent;
            int parentCount = 0;

            while (currentParent != null && parentCount < 3)
            {
                // Stop if we hit the Sitecore content root or system folders
                if (currentParent.Paths.IsContentItem == false) break;

                itemsToPublish.Add(currentParent);
                currentParent = currentParent.Parent;
                parentCount++;
            }

            // 2. Reverse the list so the top-most parent comes first
            itemsToPublish.Reverse();

            // 3. Publish each item in order
            foreach (var item in itemsToPublish)
            {
                PublishExtensions.PublishItem(item, publishSubItems);
            }
        }
        public Item CreateItem(Item item)
        {
            item = item.Versions.GetLatestVersion();
            if (!item.Locking.IsLocked())
            {
                if (item[FieldIDs.WorkflowState] == Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowDraftState)
                {
                    return item;
                }
                else
                {
                    // create new version of the item
                    return item.Versions.AddVersion();
                }
            }
            else
            {
                throw new Exception("Item is locked by " + item.Locking.GetOwner());
            }
        }

        public void SetDeletionWorkflow(Item item)
        {
            item = item.Versions.GetLatestVersion();
            item.Editing.BeginEdit();
            item[FieldIDs.WorkflowState] = Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowDeletionState;
            item.Editing.EndEdit();
        }
        public void ApprovedDeletionWorkflow(Item item)
        {
            item = item.Versions.GetLatestVersion();
            item.Editing.BeginEdit();
            item[FieldIDs.WorkflowState] = Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowDeletionApproved;
            item.Editing.EndEdit();
        }
        public string GetWorkflowStatus(EntityStatus status)
        {
            if (EntityStatus.Draft == status || EntityStatus.Pending == status || EntityStatus.Approved == status)
                return Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowDraftState;
            else if (EntityStatus.Deleted == status)
                return Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowDeletionState;
            return string.Empty;

        }
        public User GetUser()
        {
            return User.FromName(Bga.Sc.Foundation.SitecoreExtensions.Constants.User.adminUser, false);
        }
        public Item CreateItem(string itemName, ID templateId, string folder, string jurisdiction, Item parentItem = null)
        {
            // create item
            Database masterDb = Factory.GetDatabase(Bga.Sc.Foundation.SitecoreExtensions.Constants.Site.MasterDb);
            string name = !string.IsNullOrEmpty(itemName) ? itemName : Guid.NewGuid().ToString();
            name = ItemUtil.ProposeValidItemName(name);
            if (parentItem == null)
                parentItem = masterDb.GetItem(BgaItemExtensions.GetItemById(folder)?.Paths.FullPath.ToLower() + "/" + jurisdiction);
            var template = masterDb.GetTemplate(templateId);
            var newItem = parentItem.Add(name, template);
            if (string.IsNullOrEmpty(itemName))
            {
                newItem.Editing.BeginEdit();
                newItem.Appearance.DisplayName = "To be updated";
                newItem.Editing.EndEdit();
            }
            return newItem;
        }
        public ItemMappingModel UpdateCommonItemFields(Item item, string externalId, string internalId, Jurisdiction jurisdiction, EntityStatus status, EntityType type, bool sendNotification = false, string text = "")
        {
            if (!string.IsNullOrEmpty(externalId))
                item[Templates.AblisId.Fields.ExternalId] = externalId;
            if (!string.IsNullOrEmpty(internalId))
                item[Templates.AblisId.Fields.InternalId] = internalId;
            item[Templates.JurisdictionLink.Fields.JsField] = GetJurisdiction(jurisdiction);
            item[FieldIDs.UnpublishDate] = "";
            item[FieldIDs.WorkflowState] = GetWorkflowStatus(status);
            return AddItemInMappingList(item, externalId, internalId, jurisdiction, type);
        }

        public ItemMappingModel AddItemInMappingList(Item item, string externalId, string internalId, Jurisdiction jurisdiction, EntityType type, bool sendNotification = false, string text = "")
        {
            return new ItemMappingModel()
            {
                ExternalId = item[Templates.AblisId.Fields.ExternalId],
                InternalId = item[Templates.AblisId.Fields.InternalId],
                SourceItem = item,
                Type = type,
                Jurisdiction = jurisdiction.ToString(),
                SendEmailNotification = sendNotification,
                Text = text
            };
        }
        public Item GetItemBasedOnAblisId(object item, IEnumerable<IHandler> handlers, EntityType entityType, Jurisdiction? jurisdiction, out string classType)
        {
            var type = item.GetType().Name;
            var referenceItem = GetTypeItem(item, handlers, entityType, jurisdiction);
            if (type != "AblisId")
                referenceItem = UpdateChildItem(handlers, item, referenceItem, entityType);
            classType = type;
            return referenceItem;
        }

        public Item GetTypeItem(object item, IEnumerable<IHandler> handlers, EntityType entityType, Jurisdiction? jurisdiction)
        {
            Item referenceItem = null;
            var type = item.GetType().Name;
            var jurisdictionList = jurisdiction == null ? null : new[] { jurisdiction.ToString() }.ToList();
            if (type == "AblisId")
                referenceItem = (Item)GetResponseEntities(handlers, entityType, jurisdictionList, null, new[] { ((Domain.Models.AblisId)item) }.ToList(), "", "", true)?.FirstOrDefault();
            else
            {
                referenceItem = (Item)GetResponseEntities(handlers, entityType, jurisdictionList, null, new[] { GetItemAblisId(item) }.ToList(), "", "", true)?.FirstOrDefault();
            }
            return referenceItem;
        }

        public AblisId GetItemAblisId(Object item)
        {
            AblisId Id = new AblisId();

            if (item is Address) { var entityType = (Address)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Contact) { var entityType = (Contact)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Fee) { var entityType = (Fee)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is IllegalBusinessActivity) { var entityType = (IllegalBusinessActivity)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Legislation) { var entityType = (Legislation)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Organisation) { var entityType = (Organisation)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is ProcessInformation) { var entityType = (ProcessInformation)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is QuestionHint) { var entityType = (QuestionHint)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is ResourceReference) { var entityType = (ResourceReference)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Service) { var entityType = (Service)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is ServiceTask) { var entityType = (ServiceTask)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Telephone) { var entityType = (Telephone)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Domain.Models.Uri) { var entityType = (Domain.Models.Uri)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Answer) { var entityType = (Answer)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is BusinessActivity) { var entityType = (BusinessActivity)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is GeographicPolygon) { var entityType = (GeographicPolygon)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is PostCodeSuburb) { var entityType = (PostCodeSuburb)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Question) { var entityType = (Question)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is ResourceDeliveryMethod) { var entityType = (ResourceDeliveryMethod)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }
            if (item is Topic) { var entityType = (Topic)item; Id.ExternalId = entityType.Id.ExternalId; Id.InternalId = entityType.Id.InternalId; }

            return Id;
        }
        public string GetJurisdiction(Jurisdiction jurisdiction)
        {
            return BgaItemExtensions.GetItemById(Bga.Sc.Foundation.SitecoreExtensions.Templates.BusinessServices.JurisdictionsParentId.ToString())?.Children?.Where(x => x[Templates.Jurisdiction.Fields.Code] == jurisdiction.ToString())?.FirstOrDefault()?.ID.ToString();
        }
        public void DeleteItems(List<Item> items)
        {
            foreach (var item in items)
            {
                if (item != null)
                {
                    SetDeletionWorkflow(item);
                }
            }
        }

        public Item UpdateChildItem(IEnumerable<IHandler> handlers, object xmlItem, Item item, EntityType type)
        {
            var handler = handlers.FirstOrDefault(h => h.HandledType == type);
            var childItem = handler.ManageItem(handlers, xmlItem, item);

            var response = new EntityResponse
            {
                Id = childItem != null ? new AblisId()
                {
                    InternalId = !string.IsNullOrEmpty(childItem[Templates.AblisId.Fields.InternalId]) ? childItem[Templates.AblisId.Fields.InternalId] : childItem.ID.ToString(),
                    ExternalId = childItem[Templates.AblisId.Fields.ExternalId]
                } : null,
                IsSuccess = true,
                IsDeleted = childItem == null || childItem[FieldIDs.WorkflowState] == Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowDeletionState ? true : false,
            };
            AddChildResponseItem(response);
            return childItem;
        }

        private void AddChildResponseItem(EntityResponse item)
        {
            if (Response != null)
            {
                var local = this.Response.ChildEntities.ToList();
                local.Add(item);

                Response.ChildEntities = local.ToArray();
            }
        }
        public void SetUnpublishDate(Item item)
        {
            item.Editing.BeginEdit();
            DateTime pastDate = DateTime.UtcNow.AddDays(-1);
            item.Publishing.UnpublishDate = pastDate;
            item.Editing.EndEdit();

        }

        public void RemoveUnpublishDate(Item item)
        {
            if (item.Publishing.UnpublishDate != DateTime.MaxValue)
            {
                item.Editing.BeginEdit();
                item.Publishing.UnpublishDate = DateTime.MaxValue;
                item.Editing.EndEdit();
            }
        }

        public void UpdateBusinessStructure(BusinessStructure[] BS, Item item)
        {
            item[Templates.BusinessStructure.Fields.BSField] = "";
            MultilistField multilistField = item.Fields[Templates.BusinessStructure.Fields.BSField];
            var enumNames = BS?.Select(e => e.ToString()).ToList();
            var bsFolderItem = BgaItemExtensions.GetItemById(Bga.Sc.Foundation.SitecoreExtensions.Templates.BusinessServices.BusinessStructuresParentId.ToString());
            var matchingIds = bsFolderItem?.Children
        .Where(child => enumNames.Contains(child.DisplayName, StringComparer.OrdinalIgnoreCase))
        .Select(child => child.ID.ToString())
        .ToList();
            if (multilistField != null && matchingIds != null)
            {
                multilistField.Value = string.Join("|", matchingIds);
            }
        }
        private SitecoreEntityModel GetEntityFilter(EntityType type)
        {
            var entityModel = new SitecoreEntityModel();
            switch (type)
            {
                case EntityType.Address:
                    entityModel.TemplateId = Templates.Address.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.AddressFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Answer:
                    entityModel.TemplateId = Templates.Answer.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.StenningAssessmentFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.BusinessActivity:
                    entityModel.TemplateId = Templates.BusinessActivity.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.BusinessActivitiesFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Contact:
                    entityModel.TemplateId = Templates.Contact.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.ContactFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.GeographicPolygon:
                    entityModel.TemplateId = Templates.GeographicPolygon.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.GeographicPolygonFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Fee:
                    entityModel.TemplateId = Templates.Fee.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.FeeFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.IllegalBusinessActivity:
                    entityModel.TemplateId = Templates.IllegalBusinessActivity.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.IllegalBusinessActivityFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Legislation:
                    entityModel.TemplateId = Templates.Legislation.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.LegislationFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Organisation:
                    entityModel.TemplateId = Templates.Organisation.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.OrganisationFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.PostCodeSuburb:
                    entityModel.TemplateId = Templates.Suburb.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.SuburbFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.ProcessInformation:
                    entityModel.TemplateId = Templates.ProcessInformation.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.ProcessInformationFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Question:
                    entityModel.TemplateId = Templates.Question.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.StenningAssessmentFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.QuestionHint:
                    entityModel.TemplateId = Templates.HelpText.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.StenningAssessmentFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.ResourceDeliveryMethod:
                    entityModel.TemplateId = Templates.ResourceDelivery.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.ResourceDeliveryMethodFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.ResourceReference:
                    entityModel.TemplateId = Templates.ResourceReference.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.ResourceReferenceFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Service:
                    entityModel.TemplateId = Templates.Service.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.ServiceFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.ServiceTask:
                    entityModel.TemplateId = Templates.ServiceTask.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.ServiceFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Telephone:
                    entityModel.TemplateId = Templates.Phone.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.PhoneFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Topic:
                    entityModel.TemplateId = Templates.Topic.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.StenningAssessmentFolder)?.Paths.FullPath.ToLower();
                    break;
                case EntityType.Uri:
                    entityModel.TemplateId = Templates.Uri.Id;
                    entityModel.StartPath = BgaItemExtensions.GetItemById(Domain.Constants.UriFolder)?.Paths.FullPath.ToLower();
                    break;
                default:
                    throw new ArgumentException("Unknown Entity Type", "type");
            }
            return entityModel;
        }

        public virtual IEnumerable<object> GetResponseEntities(IEnumerable<IHandler> handlers, EntityType type, List<string> jurisdictionList, int? depth = null, List<AblisId> ablisIds = null, string multiListField = "", string multiListFieldValue = "", bool returnSitecoreItems = false, bool useOverrideAssessmentFolder = false)
        {
            try
            {

                var itemsList = new List<Item>();
                if (ablisIds != null && ablisIds.Count > batchSize)
                {
                    var itemsBatchList = new List<Item>();
                    for (int i = 0; i < ablisIds.Count; i += batchSize)
                    {
                        var batchIds = ablisIds.Skip(i).Take(batchSize).ToList();
                        itemsBatchList = GetSearchResultItems(handlers, type, jurisdictionList, depth, batchIds, multiListField, multiListFieldValue, useOverrideAssessmentFolder);
                        itemsList.AddRange(itemsBatchList);
                    }
                }
                else
                    itemsList = GetSearchResultItems(handlers, type, jurisdictionList, depth, ablisIds, multiListField, multiListFieldValue, useOverrideAssessmentFolder);


                if (!string.IsNullOrEmpty(multiListField) || returnSitecoreItems)
                    return itemsList;
                else
                {
                    return itemsList.Select(x =>
                    {
                        try
                        {
                            return GetResponseEntity(handlers, x, depth);
                        }
                        catch (Exception ex)
                        {
                            Logger.LogError(ex, ex.Message + "for item id " + x.ID);
                            return null;
                        }
                    }).Where(entity => entity != null).ToArray();
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, ex.Message);
                return null;
            }
        }

        public List<Item> GetSearchResultItems(IEnumerable<IHandler> handlers, EntityType type, List<string> jurisdictionList, int? depth = null, List<AblisId> ablisIds = null, string multiListField = "", string multiListFieldValue = "", bool useOverrideAssessmentFolder = false)
        {
            var itemsList = new List<Item>();
            if (ablisIds != null && ablisIds.Count == 1 && ItemsCreatedInRequest.Count > 0)
            {
                itemsList = ItemsCreatedInRequest.Where(x => x.Type == type && ((!string.IsNullOrEmpty(ablisIds.FirstOrDefault().ExternalId) && x.ExternalId == ablisIds.FirstOrDefault().ExternalId) ||
                (!string.IsNullOrEmpty(ablisIds.FirstOrDefault().InternalId) && x.InternalId == ablisIds.FirstOrDefault().InternalId))).Select(x => x.SourceItem)?.ToList();
            }
            if (!itemsList.Any())
            {
                var index = ContentSearchManager.GetIndex("sitecore_master_index");

                using (var context = index.CreateSearchContext())
                {
                    var sitecoreEntityDetails = GetEntityFilter(type);

                    // Build a dynamic OR predicate for multiple IDs
                    var predicate = PredicateBuilder.True<SearchResultItem>();
                    var jurisdictionPredicate = PredicateBuilder.False<SearchResultItem>();

                    if (ablisIds != null)
                    {
                        foreach (var id in ablisIds)
                        {
                            if (!string.IsNullOrEmpty(id.InternalId))
                                predicate = predicate.Or(item => item["InternalId"] == id.InternalId);
                            else if (!string.IsNullOrEmpty(id.ExternalId))
                                predicate = predicate.Or(item => item["External Id"] == id.ExternalId);
                        }
                    }

                    if (!string.IsNullOrEmpty(multiListField))
                    {
                        predicate = predicate.And(item => item[multiListField] == multiListFieldValue);
                    }

                    if (useOverrideAssessmentFolder)
                    {
                        var path = BgaItemExtensions.GetItemById(Bga.Sc.Foundation.SitecoreExtensions.Constants.Ablis.AblisToolContainerItemId)?.Paths.FullPath.ToLower();
                        predicate = predicate.And(item => item.Path.Contains(path));
                        predicate = predicate.And(item => item.TemplateId == Templates.AssessmentAnswer.Id);
                    }
                    else
                    {
                        predicate = predicate.And(item => item.Path.Contains(sitecoreEntityDetails.StartPath));

                        if (type == EntityType.Topic)
                            predicate = predicate.And(item => item.TemplateId == sitecoreEntityDetails.TemplateId || item.TemplateId == Templates.Category.Id);
                        else
                            predicate = predicate.And(item => item.TemplateId == sitecoreEntityDetails.TemplateId);
                    }


                    if (sitecoreEntityDetails.StartPath != BgaItemExtensions.GetItemById(Domain.Constants.StenningAssessmentFolder)?.Paths.FullPath.ToLower() && type != EntityType.BusinessActivity && type != EntityType.GeographicPolygon && type != EntityType.PostCodeSuburb && type != EntityType.ResourceDeliveryMethod && jurisdictionList != null && jurisdictionList.Any())
                    {
                        foreach (var jurisdiction in jurisdictionList)
                        {
                            jurisdictionPredicate = jurisdictionPredicate.Or(item => item["cJurisdiction"] == jurisdiction);
                        }
                        predicate = predicate.And(jurisdictionPredicate);
                    }

                    //// 3. Query the index filtering by Path and Template ID
                    var results = context.GetQueryable<SearchResultItem>()
                        .Where(predicate)
                        .ToList();

                    // 4. Convert search results back to Sitecore Items
                    foreach (var result in results)
                    {
                        Item item = result.GetItem();
                        if (item != null)
                        {
                            itemsList.Add(item);
                        }
                    }
                }
            }
            return itemsList;
        }
        public virtual object GetResponseEntity(IEnumerable<IHandler> handlers, Item item, int? depth = null)
        {
            try
            {
                return this.GetResponseEntity(handlers, item, depth);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, ex.Message);
                return null;
            }
        }
        /// <summary>
        /// Find any servicetasks that have been removed from the XML request, but are in the database
        /// Delete any that are found before we process the incoming request
        /// </summary>
        public bool DeleteRemovedServiceTasks(IEnumerable<IHandler> handlers, IHandler handler, List<string> stIds, AblisId sId, string jurisdiction)
        {
            List<AblisId> ablisIds = new[] { sId }.ToList();

            // Get the serviceId from the externalId
            var serviceItem = (Item)handler.GetResponseEntities(handlers, EntityType.Service, jurisdiction?.Split(',').ToList(), 1, ablisIds, "", "", true)?.FirstOrDefault();

            // Will be zero if this is a new Service, so it won't exist in the sitecore
            if (serviceItem == null)
            {
                return false;
            }

            var abId = new AblisId();
            bool exists = false;
            var stIdsArray = stIds.ToArray();

            try
            {
                //Get all the current services servicetasks from the sitecore related to this serviceId
                var serviceTaksItems = BgaItemExtensions.GetChildItemsOfModelType(serviceItem, Bga.Sc.Foundation.SitecoreExtensions.Templates.ServiceTask.Id).ToList();
                var serviceTaskIds = serviceTaksItems?.Select(x => x[Templates.AblisId.Fields.ExternalId])
                    .ToArray();

                //Now check the sitecore data against the request data.  If the servicetask is in the sitecore, but not in the request
                bool updatedRecords = false;
                foreach (var stItem in serviceTaksItems)
                {
                    exists = Array.Exists(stIdsArray, element => element == stItem[Templates.AblisId.Fields.ExternalId]);

                    // If there is a servicetask in the sitecore which is not in the request - Delete the item
                    if (!exists && stItem != null && !string.IsNullOrEmpty(stItem[Templates.AblisId.Fields.ExternalId]))
                    {
                        User scUser = GetUser();
                        using (new UserSwitcher(scUser))
                        {
                            SetUnpublishDate(stItem);
                            SetDeletionWorkflow(stItem);
                        }
                        updatedRecords = true;
                    }
                }
                if (updatedRecords)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return false;
        }

        public Item GetLastApprovedVersion(Item item)
        {
            if (item == null) return null;

            // Get all versions of the item in the current language
            Item[] versions = item.Versions.GetVersions(true);

            // Loop backwards from the latest version to the oldest version
            for (int i = versions.Length - 1; i >= 0; i--)
            {
                Item version = versions[i];
                IWorkflow workflow = version.Database.WorkflowProvider.GetWorkflow(version);

                if (workflow != null)
                {
                    WorkflowState state = workflow.GetState(version);
                    // Check if the workflow state is marked as final (Approved)
                    if (state != null && state.FinalState)
                    {
                        return version; // This is the latest approved version
                    }
                }
            }

            return null; // No approved version found
        }
        public List<(int Code, string Description)> GetErrors()
        {
            return Errors;
        }

        public void SetItemList(List<ItemMappingModel> ItemsInAllRequests)
        {
            ItemsCreatedInRequest = ItemsInAllRequests;
        }
        public EntityResponse ManageContent(IEnumerable<IHandler> handlers, IHandler handler, EntityType type, AblisId ablisId, object xmlItem, Jurisdiction jurisdiction, out List<ItemMappingModel> itemsCreatedInRequests)
        {
            this.Response = new EntityResponse
            {
                Id = ablisId,
                ChildEntities = new EntityResponse[] { },
                IsSuccess = true,
            };
            Item item = null;

            if (ablisId != null && (ablisId.ExternalId != null || ablisId.InternalId != null))
            {
                // Get the item from the ablis id
                List<AblisId> ablisIds = new[] { ablisId }.ToList();
                item = (Item)handler.GetResponseEntities(handlers, type, new[] { jurisdiction.ToString() }.ToList(), 1, ablisIds, "", "", true)?.FirstOrDefault();
            }
            item = ManageItem(handlers, xmlItem, item);
            if (item == null)
                Response.IsSuccess = false;
            else
            {
                Response.Id.InternalId = !string.IsNullOrEmpty(item[Templates.AblisId.Fields.InternalId]) ? item[Templates.AblisId.Fields.InternalId] : item.ID.ToString();
                Response.IsDeleted = item[FieldIDs.WorkflowState] == Bga.Sc.Foundation.SitecoreExtensions.Constants.Workflow.BgaWorkFlowDeletionState;
            }
            itemsCreatedInRequests = ItemsCreatedInRequest;
            return Response;
        }

        public EntityResponse Process(IEnumerable<IHandler> handlers, IHandler handler, AblisId ablisId, EntityType type, ManageContentAction action, Jurisdiction jurisdiction)
        {
            this.Response = new EntityResponse
            {
                Id = ablisId,
                IsSuccess = true,
            };
            Item item = null;
            if (ablisId != null && (ablisId.ExternalId != null || ablisId.InternalId != null))
            {
                // Get the item from the ablis id
                List<AblisId> ablisIds = new[] { ablisId }.ToList();
                item = (Item)handler.GetResponseEntities(handlers, type, new[] { jurisdiction.ToString() }.ToList(), 1, ablisIds, "", "", true)?.FirstOrDefault();
            }
            if (item == null)
            {
                Response.IsSuccess = false;
                return Response;
            }
            try
            {
                User scUser = User.FromName(Bga.Sc.Foundation.SitecoreExtensions.Constants.User.adminUser, false);
                using (new UserSwitcher(scUser))
                {
                    if (action == ManageContentAction.Unpublish)
                    {
                        SetUnpublishDate(item);
                        PublishExtensions.PublishItem(item, true);
                    }
                    else if (action == ManageContentAction.Delete)
                    {
                        SetUnpublishDate(item);
                        PublishExtensions.PublishItem(item, true);
                        SetDeletionWorkflow(item);
                        Response.IsDeleted = true;
                    }
                    else if (action == ManageContentAction.PublishLive)
                    {
                        item = PublishLive(handlers, action, item);
                    }
                    else if (action == ManageContentAction.UnlockCommit)
                    {
                        var latestVersionItem = item.Versions.GetLatestVersion();
                        latestVersionItem.Locking.Unlock();
                    }
                }
                Response.Id.InternalId = item == null ? null : !string.IsNullOrEmpty(item[Templates.AblisId.Fields.InternalId]) ? item[Templates.AblisId.Fields.InternalId] : item.ID.ToString();
                return Response;
            }
            catch (Exception ex)
            {
                this.Errors.Add((int.Parse(Ablis.Api.Domain.Constants.UnexpectedErrorCode), ex.Message));
                Logger.LogError(ex, ex.Message);
            }

            return Response;
        }
        public virtual Item ManageItem(IEnumerable<IHandler> handlers, object xmlItem, Item item)
        {
            try
            {
                ManageItem(handlers, xmlItem, item);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, ex.Message);
            }
            return item;
        }
        public virtual Item PublishLive(IEnumerable<IHandler> handlers, ManageContentAction action, Item item)
        {
            try
            {
                PublishLive(handlers, action, item);
            }
            catch (Exception ex)
            {
                this.Errors.Add((int.Parse(Ablis.Api.Domain.Constants.UnexpectedErrorCode), ex.Message));
                Logger.LogError(ex, ex.Message);
            }
            return item;
        }
    }
}
