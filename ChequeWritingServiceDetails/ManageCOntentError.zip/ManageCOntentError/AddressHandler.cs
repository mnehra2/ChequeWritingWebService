﻿using Ablis.Api.Application.Interfaces;
using Ablis.Api.Domain;
using Ablis.Api.Domain.Models;
using Ablis.Api.Domain.Models.AddressModels;
using Bga.Sc.Foundation.AuditTrail.Helper;
using Bga.Sc.Foundation.DependencyInjection;
using Bga.Sc.Foundation.SitecoreExtensions.Extensions;
using Sitecore.Data.Items;
using Sitecore.Security.Accounts;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Ablis.Api.Application.Handlers
{
    [Service(Lifetime = Lifetime.Transient, ServiceType = typeof(IHandler))]
    public class AddressHandler : CommonDataHandler<Address>
    {
        public AddressHandler(ILogger logger) : base(logger) { }

        public AddressHandler(AblisId id, ILogger logger) : base(logger) { }

        public override EntityType HandledType => EntityType.Address;

        public override object GetResponseEntity(IEnumerable<IHandler> handlers, Item item, int? depth = null)
        {
            if (item == null) return null;
            if (depth == null || depth < 0) return GetAblisId(item);
            var jurisdiction = BgaItemExtensions.GetItemById(item[Templates.JurisdictionLink.Fields.JsField]);
            var country = BgaItemExtensions.GetItemById(item[Templates.Address.Fields.Country]);
            int? dpid = int.TryParse(item[Templates.Address.Fields.DeliveryPoint], out int parsedValue) ? (int?)parsedValue : null;
            var response = new Address
            {
                Id = GetAblisId(item),
                Status = (EntityStatus)GetWorkflowStatus(item),
                StatusSpecified = true,
                Jurisdiction = jurisdiction != null ? jurisdiction[Templates.Jurisdiction.Fields.Code].ToEnum<Jurisdiction>() : Jurisdiction.ANY,
                Country = country != null && !string.IsNullOrEmpty(country[Templates.CodeName.Fields.Code]) ? country?[Templates.CodeName.Fields.Code].ToEnum<Country>() : null,
                CountrySpecified = country != null && !string.IsNullOrEmpty(country[Templates.Jurisdiction.Fields.Code]),
                DeliveryPoint = dpid,
                DeliveryPointSpecified = dpid.HasValue,
                PhysicalAccessibility = item[Templates.Address.Fields.PhysicalAccessibility]
            };

            if (!string.IsNullOrEmpty(item[Templates.Address.Fields.Line1]))
            {
                var address = new AddressLines
                {
                    Line1 = item[Templates.Address.Fields.Line1],
                    Line2 = item[Templates.Address.Fields.Line2],
                    Line3 = item[Templates.Address.Fields.Line3],
                    Line4 = item[Templates.Address.Fields.Line4],
                };

                response.Item = address;
            }
            else
            {
                response.Item = GetStructuredAddress(item);
            }
            return response;
        }

        public override Item ManageItem(IEnumerable<IHandler> handlers, object xmlItem, Item item)
        {
            Item newItem = null;
            try
            {
                Address addressData = (Address)xmlItem;
                User scUser = GetUser();
                using (new UserSwitcher(scUser))
                {

                    if (item == null)
                    {
                        // create item
                        newItem = CreateItem(addressData.Id.ExternalId, Templates.Address.Id, Domain.Constants.AddressFolder, addressData.Jurisdiction.ToString());
                    }
                    else
                    {
                        // create new version of the item
                        newItem = CreateItem(item);
                    }
                    try
                    {
                        newItem.Editing.BeginEdit();
                        ClearAddress(newItem);
                        var updatedItem = UpdateCommonItemFields(newItem, addressData.Id.ExternalId, addressData.Id.InternalId, addressData.Jurisdiction, addressData.Status, EntityType.Address);
                        newItem[Templates.Address.Fields.PhysicalAccessibility] = addressData.PhysicalAccessibility;
                        newItem[Templates.Address.Fields.Country] = addressData.Country != null ? BgaItemExtensions.GetItemById(Domain.Constants.CountriesFolder)?.Children?.Where(x => x[Templates.CodeName.Fields.Code] == addressData.Country.ToString())?.FirstOrDefault()?.ID.ToString() : string.Empty;
                        newItem[Templates.Address.Fields.DeliveryPoint] = addressData.DeliveryPoint != null ? addressData.DeliveryPoint.ToString() : string.Empty;
                        if (addressData.Item is AddressLines)
                        {
                            var lines = addressData.Item as AddressLines;
                            newItem[Templates.Address.Fields.Line1] = lines.Line1;
                            newItem[Templates.Address.Fields.Line2] = lines.Line2;
                            newItem[Templates.Address.Fields.Line3] = lines.Line3;
                            newItem[Templates.Address.Fields.Line4] = lines.Line4;
                        }
                        else if (addressData.Item is AddressStructuredAddress)
                        {
                            var structured = addressData.Item as AddressStructuredAddress;
                            newItem[Templates.Address.Fields.Locality] = structured.Locality;
                            newItem[Templates.Address.Fields.LocationDescriptor] = structured.LocationDescriptor;
                            newItem[Templates.Address.Fields.SiteName] = structured.SiteName;
                            newItem[Templates.Address.Fields.StateTerritory] = structured.StateTerritory != null ? BgaItemExtensions.GetItemById(Bga.Sc.Foundation.SitecoreExtensions.Templates.BusinessServices.JurisdictionsParentId.ToString())?.Children?.Where(x => x[Templates.Jurisdiction.Fields.Code] == structured.StateTerritory.ToString())?.FirstOrDefault()?.ID.ToString() : string.Empty;

                            var postcode = structured.Postcode.ToString();
                            var postcodePaddedWithZeros = postcode.PadLeft(4, '0');
                            var locality = structured.Locality;
                            var state = structured.StateTerritory.ToDescriptionString();

                            newItem[Templates.Address.Fields.Postcode] = postcodePaddedWithZeros;

                            if (structured.Item is AddressStructuredAddressPostalDelivery)
                            {
                                var delivery = (AddressStructuredAddressPostalDelivery)structured.Item;

                                newItem[Templates.Address.Fields.PostalDeliveryNumber] = delivery.Number;
                                newItem[Templates.Address.Fields.PostalDeliveryType] = delivery.Type != null ? BgaItemExtensions.GetItemById(Domain.Constants.AddressPostalDeliveryTypeFolder)?.Children?.Where(x => x[Templates.CodeName.Fields.Code] == delivery.Type.ToString())?.FirstOrDefault()?.ID.ToString() : string.Empty;
                            }
                            else if (structured.Item is AddressStructuredAddressStreet)
                            {
                                var street = (AddressStructuredAddressStreet)structured.Item;

                                var streetNumber = 1;
                                for (var i = 0; i < street.ItemsElementName.Length; i++)
                                {
                                    switch (street.ItemsElementName[i])
                                    {
                                        case ItemsChoiceType.LotNumber:
                                            {
                                                newItem[Templates.Address.Fields.StreetLotNumber] = street.Items[i];
                                                break;
                                            }
                                        case ItemsChoiceType.Number:
                                            {
                                                var numbers = street.Items[i];
                                                switch (streetNumber)
                                                {
                                                    case 1:
                                                        newItem[Templates.Address.Fields.StreetNumber] = numbers;
                                                        streetNumber += 1;
                                                        break;
                                                    case 2:
                                                        newItem[Templates.Address.Fields.StreetNumber2] = numbers;
                                                        streetNumber += 1;
                                                        break;
                                                }
                                                break;
                                            }
                                    }
                                }

                                newItem[Templates.Address.Fields.StreetName] = street.Name;
                                newItem[Templates.Address.Fields.StreetType] = street.Type != null ? BgaItemExtensions.GetItemById(Domain.Constants.AddressStreetTypeFolder)?.Children?.Where(x => x[Templates.CodeName.Fields.Code] == street.Type.ToString())?.FirstOrDefault()?.ID.ToString() : string.Empty;
                                newItem[Templates.Address.Fields.StreetSuffix] = street.Suffix != null ? BgaItemExtensions.GetItemById(Domain.Constants.AddressStreetSuffixTypeFolder)?.Children?.Where(x => x[Templates.CodeName.Fields.Code] == street.Suffix.ToString())?.FirstOrDefault()?.ID.ToString() : string.Empty;
                            }

                            if (structured.SubComplexAddress != null)
                            {
                                var complex = structured.SubComplexAddress;
                                newItem[Templates.Address.Fields.IsSubComplexAddress] = "1";

                                if (complex.Unit != null)
                                {
                                    newItem[Templates.Address.Fields.UnitType] = complex.Unit.UnitType != null ? BgaItemExtensions.GetItemById(Domain.Constants.AddressUnitTypeFolder)?.Children?.Where(x => x[Templates.CodeName.Fields.Code] == complex.Unit.UnitType.ToString())?.FirstOrDefault()?.ID.ToString() : string.Empty;
                                    newItem[Templates.Address.Fields.UnitNumber] = complex.Unit.UnitNumber;
                                }

                                if (complex.Level != null)
                                {
                                    newItem[Templates.Address.Fields.LevelType] = complex.Level.LevelType != null ? BgaItemExtensions.GetItemById(Domain.Constants.AddressLevelTypeFolder)?.Children?.Where(x => x[Templates.CodeName.Fields.Code] == complex.Level.LevelType.ToString())?.FirstOrDefault()?.ID.ToString() : string.Empty;
                                    newItem[Templates.Address.Fields.LevelNumber] = complex.Level.LevelNumber;
                                }

                                if (complex.Street != null)
                                {
                                    newItem[Templates.Address.Fields.StreetName] = complex.Street.StreetName;

                                    if (complex.Street.StreetNumber != null && (complex.Street.StreetNumber.Length >= 1 || complex.Street.StreetNumber.Length <= 2))
                                    {
                                        newItem[Templates.Address.Fields.StreetNumber] = complex.Street.StreetNumber[0];
                                        newItem[Templates.Address.Fields.StreetNumber2] = (complex.Street.StreetNumber.Length == 2) ? complex.Street.StreetNumber[1] : string.Empty;
                                    }

                                    newItem[Templates.Address.Fields.StreetType] = complex.Street.StreetType != null ? BgaItemExtensions.GetItemById(Domain.Constants.AddressStreetTypeFolder)?.Children?.Where(x => x[Templates.CodeName.Fields.Code] == complex.Street.StreetType.ToString())?.FirstOrDefault()?.ID.ToString() : string.Empty;
                                    newItem[Templates.Address.Fields.StreetSuffix] = complex.Street.StreetSuffix != null ? BgaItemExtensions.GetItemById(Domain.Constants.AddressStreetSuffixTypeFolder)?.Children?.Where(x => x[Templates.CodeName.Fields.Code] == complex.Street.StreetSuffix.ToString())?.FirstOrDefault()?.ID.ToString() : string.Empty;
                                }

                                newItem[Templates.Address.Fields.ComplexName] = complex.ComplexName;
                            }
                        }
                        newItem.Editing.EndEdit();
                        ItemsCreatedInRequest.Add(updatedItem);
                        if (item == null)
                            PushItemToIndex(newItem);
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex);
                        this.Errors.Add((int.Parse(Constants.UnexpectedErrorCode), ex.Message));
                        newItem.Editing.CancelEdit();
                    }
                }
            }
            catch (System.Exception ex)
            {
                this.Errors.Add((int.Parse(Constants.UnexpectedErrorCode), ex.Message));
                Logger.LogError(ex, ex.Message);
            }
            return newItem;
        }

        public override Item PublishLive(IEnumerable<IHandler> handlers, ManageContentAction action, Item item)
        {
            try
            {
                Publish(item);
            }
            catch (Exception ex)
            {
                this.Errors.Add((int.Parse(Constants.UnexpectedErrorCode), ex.Message));
                Logger.LogError(ex, ex.Message);
            }
            return item;
        }

        private void ClearAddress(Item item)
        {
            item[Templates.Address.Fields.Country] = null;
            item[Templates.Address.Fields.DeliveryPoint] = null;
            item[Templates.Address.Fields.PhysicalAccessibility] = null;

            ClearUnstructuredFields(item);
            ClearStructuredFields(item);
        }
        private void ClearStructuredFields(Item item)
        {
            item[Templates.Address.Fields.ComplexName] = null;
            item[Templates.Address.Fields.UnitNumber] = null;
            item[Templates.Address.Fields.LevelNumber] = null;
            item[Templates.Address.Fields.StreetNumber] = null;
            item[Templates.Address.Fields.StreetNumber2] = null;
            item[Templates.Address.Fields.UnitType] = null;
            item[Templates.Address.Fields.LevelType] = null;
            item[Templates.Address.Fields.StreetName] = null;
            item[Templates.Address.Fields.StreetSuffix] = null;
            item[Templates.Address.Fields.StreetType] = null;
            item[Templates.Address.Fields.LocationDescriptor] = null;
            item[Templates.Address.Fields.SiteName] = null;
            item[Templates.Address.Fields.StreetLotNumber] = null;
            item[Templates.Address.Fields.Locality] = null;
            item[Templates.Address.Fields.StreetLotNumber] = null;
            item[Templates.Address.Fields.PostalDeliveryNumber] = null;
            item[Templates.Address.Fields.PostalDeliveryType] = null;
            item[Templates.Address.Fields.Postcode] = null;
            item[Templates.Address.Fields.StateTerritory] = null;
            item[Templates.Address.Fields.IsSubComplexAddress] = "0";
        }

        private void ClearUnstructuredFields(Item item)
        {
            item[Templates.Address.Fields.Line1] = null;
            item[Templates.Address.Fields.Line2] = null;
            item[Templates.Address.Fields.Line3] = null;
            item[Templates.Address.Fields.Line4] = null;
        }

        private AddressStructuredAddress GetStructuredAddress(Item item)
        {
            var unitType = BgaItemExtensions.GetItemById(item[Templates.Address.Fields.UnitType]);
            var levelType = BgaItemExtensions.GetItemById(item[Templates.Address.Fields.LevelType]);
            var streetType = BgaItemExtensions.GetItemById(item[Templates.Address.Fields.StreetType]);
            var streetSuffixType = BgaItemExtensions.GetItemById(item[Templates.Address.Fields.StreetSuffix]);
            var postalDeliveryType = BgaItemExtensions.GetItemById(item[Templates.Address.Fields.PostalDeliveryType]);
            var stType = BgaItemExtensions.GetItemById(item[Templates.Address.Fields.StateTerritory]);
            var address = new AddressStructuredAddress
            {
                SiteName = item[Templates.Address.Fields.SiteName],
                Locality = item[Templates.Address.Fields.Locality],
                LocationDescriptor = item[Templates.Address.Fields.LocationDescriptor],
                StateTerritory = stType?[Templates.Jurisdiction.Fields.Code].ToEnum<StateTerritoryType>()
            };

            if (item[Templates.Address.Fields.Postcode] != null)
            {
                var postcode = 0;
                if (int.TryParse(item[Templates.Address.Fields.Postcode], out postcode))
                {
                    address.Postcode = postcode;
                }
            }

            if (item.Fields[Templates.Address.Fields.IsSubComplexAddress].IsChecked() && (!string.IsNullOrEmpty(item[Templates.Address.Fields.UnitType]) || !string.IsNullOrEmpty(item[Templates.Address.Fields.LevelType]) || !string.IsNullOrEmpty(item[Templates.Address.Fields.StreetName]) || !string.IsNullOrEmpty(item[Templates.Address.Fields.StreetNumber])))
            {
                address.SubComplexAddress = new AddressStructuredAddressSubComplexAddress();

                if (unitType != null)
                {
                    address.SubComplexAddress.Unit = new AddressStructuredAddressSubComplexAddressUnit
                    {
                        UnitType = unitType[Templates.CodeName.Fields.Code].ToEnum<UnitType>(),
                        UnitNumber = item[Templates.Address.Fields.UnitNumber]
                    };
                }

                if (levelType != null)
                {
                    address.SubComplexAddress.Level = new AddressStructuredAddressSubComplexAddressLevel
                    {
                        LevelType = levelType[Templates.CodeName.Fields.Code].ToEnum<LevelType>(),
                        LevelNumber = item[Templates.Address.Fields.LevelNumber]
                    };
                }

                if (!string.IsNullOrEmpty(item[Templates.Address.Fields.StreetName]) || !string.IsNullOrEmpty(item[Templates.Address.Fields.StreetNumber]))
                {
                    address.SubComplexAddress.Street = new AddressStructuredAddressSubComplexAddressStreet
                    {
                        StreetName = item[Templates.Address.Fields.StreetName],
                        StreetSuffix = streetSuffixType?[Templates.CodeName.Fields.Code].ToEnum<StreetSuffixType>(),
                        StreetSuffixSpecified = streetSuffixType != null,
                        StreetType = streetType?[Templates.CodeName.Fields.Code].ToEnum<StreetType>(),
                        StreetTypeSpecified = streetType != null
                    };

                    var numbers = new List<string>();
                    if (!string.IsNullOrEmpty(item[Templates.Address.Fields.StreetNumber]))
                        numbers.Add(item[Templates.Address.Fields.StreetNumber]);
                    if (!string.IsNullOrEmpty(item[Templates.Address.Fields.StreetNumber2]))
                        numbers.Add(item[Templates.Address.Fields.StreetNumber2]);

                    address.SubComplexAddress.Street.StreetNumber = numbers.ToArray();
                }

                address.SubComplexAddress.ComplexName = item[Templates.Address.Fields.ComplexName];
            }

            if (postalDeliveryType != null)
            {
                address.Item = new AddressStructuredAddressPostalDelivery
                {
                    Number = item[Templates.Address.Fields.PostalDeliveryNumber],
                    Type = postalDeliveryType?[Templates.CodeName.Fields.Code].ToEnum<PostalDeliveryType>()
                };
            }
            else if (!string.IsNullOrEmpty(item[Templates.Address.Fields.StreetName]) || !string.IsNullOrEmpty(item[Templates.Address.Fields.StreetNumber]) || !string.IsNullOrEmpty(item[Templates.Address.Fields.StreetLotNumber]) || !string.IsNullOrEmpty(item[Templates.Address.Fields.StreetType]))
            {
                var street = new AddressStructuredAddressStreet
                {
                    Name = item[Templates.Address.Fields.StreetName],
                    Suffix = streetSuffixType?[Templates.CodeName.Fields.Code].ToEnum<StreetSuffixType>(),
                    SuffixSpecified = streetSuffixType != null,
                    Type = streetType?[Templates.CodeName.Fields.Code].ToEnum<StreetType>(),
                };

                var bits = new List<string>();
                var types = new List<ItemsChoiceType>();

                if (!string.IsNullOrEmpty(item[Templates.Address.Fields.StreetLotNumber]))
                {
                    bits.Add(item[Templates.Address.Fields.StreetLotNumber]);
                    types.Add(ItemsChoiceType.LotNumber);
                }
                else
                {
                    if (!string.IsNullOrEmpty(item[Templates.Address.Fields.StreetNumber]))
                    {
                        bits.Add(item[Templates.Address.Fields.StreetNumber]);
                        types.Add(ItemsChoiceType.Number);
                    }

                    if (!string.IsNullOrEmpty(item[Templates.Address.Fields.StreetNumber2]))
                    {
                        bits.Add(item[Templates.Address.Fields.StreetNumber2]);
                        types.Add(ItemsChoiceType.Number);
                    }
                }

                street.Items = bits.ToArray();
                street.ItemsElementName = types.ToArray();

                address.Item = street;
            }

            return address;
        }
    }
}
