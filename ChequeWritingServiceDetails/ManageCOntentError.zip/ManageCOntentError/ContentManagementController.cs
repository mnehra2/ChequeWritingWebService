﻿using Ablis.Api.Application.Interfaces;
using Ablis.Api.Attributes;
using Ablis.Api.Domain.Models;
using System;
using System.Net;
using System.Web.Http;

namespace Ablis.Api.Controllers
{
    [TokenAuthorize]
    [RequestTimer]
    public class ContentManagementController : ApiController
    {
        private readonly ILogger _logger;
        private readonly IContentManagementService _contentManagementService;

        public ContentManagementController(IContentManagementService contentManagementService, ILogger logger)
        {
            _logger = logger;
            _contentManagementService = contentManagementService;
        }

        [HttpPost]
        [SwaggerTags("Publish")]
        public IHttpActionResult ManageContent(ManageContentRequest request)
        {
            try
            {
                _logger.LogDebug($"Received ContentManagementController.ManageContent request. Starting at: {DateTime.Now:dd-MMM-yyyy HH:mm:ss}");

                if (request == null)
                {
                    _logger.LogWarning("ContentManagementController.ManageContent request is null");
                    return BadRequest("Request must not be null");
                }
                var response = _contentManagementService.ManageContent(request);
                return Content(HttpStatusCode.OK, response, Configuration.Formatters.XmlFormatter);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while processing ContentManagementController.ManageContent request");

                return InternalServerError(new Exception($"{ex.Message} --- CorrelationId:{_logger.GetCorrelationId()}"));
            }
            finally
            {
                _logger.LogDebug($"End ContentManagementController.ManageContent request. Finished at: {DateTime.Now:dd-MMM-yyyy HH:mm:ss}");
            }
        }

        [SwaggerTags("Publish")]
        [HttpPost]
        public IHttpActionResult ManageEntities(ManageEntitiesRequest request)
        {
            try
            {
                _logger.LogDebug($"Received ContentManagementController.ManageContent request. Starting at: {DateTime.Now:dd-MMM-yyyy HH:mm:ss}");

                if (request == null)
                {
                    _logger.LogWarning("ContentManagementController.ManageEntities request is null");
                    return BadRequest("Request must not be null");
                }
                var response = _contentManagementService.ManageEntities(request);
                return Content(HttpStatusCode.OK, response, Configuration.Formatters.XmlFormatter);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while processing ContentManagementController.ManageEntities request");

                return InternalServerError(new Exception($"{ex.Message} --- CorrelationId:{_logger.GetCorrelationId()}"));
            }
            finally
            {
                _logger.LogDebug($"End ContentManagementController.ManageEntities request. Finished at: {DateTime.Now:dd-MMM-yyyy HH:mm:ss}");
            }
        }
    }
}
