Changed files:
Sitecore.SessionProvider.dll
Sitecore.SessionProvider.Redis.dll
Sitecore.Xdb.ReferenceData.Core.dll
StackExchange.Redis.dll
Microsoft.AspNet.SessionState.SessionStateModule.dll
Microsoft.Bcl.AsyncInterfaces.dll
Pipelines.Sockets.Unofficial.dll
System.Buffers.dll
System.Diagnostics.PerformanceCounter.dll
System.IO.Pipelines.dll
System.Memory.dll
System.Numerics.Vectors.dll
System.Runtime.CompilerServices.Unsafe.dll
System.Threading.Channels.dll
System.Threading.Tasks.Extensions.dll

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Installation Instructions:

This hotfix need to be installed on top of Sitecore 9.3.0 rev. 003498

New settings were added to Session state provider:
- lockAgeMilliseconds - the maximum amount of time in milliseconds during which an item may stay locked in shared session state
	should be equeal to value from sitecore/tracking/sharedSessionState/config/maxLockAge (default value 5 sec) + sitecore/settings/Analytics.MaxAcceptedClockDeviation (default value 10 sec)
- connectionPoolSize - controls the number of IConnectionMultiplexers created for comunication with Redis, default value = 1
	optimal value for high loaded system connectionPoolSize= number of cors / 2 (connectionPoolSize="8" for 16 core machine)
	
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

1. Hotfix should be installed on CM/CD instances:
	- manually copy files from the /bin folder to CM/CD instances
	- manually copy /sitecore/shell/hotfixes/SC Hotfix 436551-1.txt file to CM instance

2. Manually apply changes to the website web.config file
	2.1 In <modules> section replace
		<add name="Session" type="System.Web.SessionState.SessionStateModule" preCondition="" /> 
		with
		<add name="Session" type="Microsoft.AspNet.SessionState.SessionStateModuleAsync, Microsoft.AspNet.SessionState.SessionStateModule, Version=1.1.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" preCondition="" />
	
	2.2 Add new assemblyBindings:
		<!-- Necessary for the latest StackExchange.Redis driver -->
		<dependentAssembly>
			<assemblyIdentity name="System.Runtime.CompilerServices.Unsafe" publicKeyToken="b03f5f7f11d50a3a" culture="neutral"/>
			<bindingRedirect oldVersion="0.0.0.0-4.0.6.0" newVersion="4.0.6.0"/>
		</dependentAssembly>
		<dependentAssembly>
			<assemblyIdentity name="System.Threading.Tasks.Extensions" publicKeyToken="cc7b13ffcd2ddd51" culture="neutral"/>
			<bindingRedirect oldVersion="0.0.0.0-4.2.0.1" newVersion="4.2.0.1"/>
		</dependentAssembly>
	
	2.3 In private session state provider replace:
		- RedisSessionStateProvider with RedisSessionStateProviderAsync for redis provider:
			<add name="redisasync" type="Sitecore.SessionProvider.Redis.RedisSessionStateProviderAsync, Sitecore.SessionProvider.Redis" applicationName="private" connectionString="redis.sessions" connectionPoolSize="8" pollingEnabled="true" retryTimeoutInMilliseconds="15000" operationTimeoutInMilliseconds="2000" compression="true" />
		
	    - "Sitecore.SessionManagement.ConditionalSessionIdManager" with "Sitecore.SessionManagement.ConditionalSessionIdManager,Sitecore.Kernel" in sessionState section:	   
			<sessionState mode="Custom" customProvider="redisasync" cookieless="false" timeout="20" sessionIDManagerType="Sitecore.SessionManagement.ConditionalSessionIdManager,Sitecore.Kernel">
	
	2.4 Adjust settings for RedisSessionStateProviderAsync:
		- Set retryTimeoutInMilliseconds="15000" - value set to 15 seconds reduces the number of RedisTimeouts to zero, but not significantly impact 99 % line response time.
		- Set operationTimeoutInMilliseconds="2000" - optimal value for high loaded system based on performance testing results
		- Set compression="true" - to reduce size of session object send to redis
		- Set connectionPoolSize="8" - this setting controls the number of IConnectionMultiplexers created for comunication with Redis, default value = 1, optimal value for high loaded system connectionPoolSize= number of cors / 2 (connectionPoolSize="8" for 16 core machine)

3. Patch redis session state provider for shared session with new settings (App_Config/Sitecore/Azure/Sitecore.Analytics.Tracking.Azure.config)
	- Set lockAgeMilliseconds="15000" - value should be equeal to maxLockAge (5000) + Analytics.MaxAcceptedClockDeviation (10000)
	- Set retryTimeoutInMilliseconds="15000" - value set to 15 seconds reduces the number of RedisTimeouts to zero, but not significantly impact 99 % line response time.
	- Set operationTimeoutInMilliseconds="2000" - optimal value for high loaded system based on performance testing results
	- Set compression="true" - to reduce size of session object send to redis
	- Set connectionPoolSize="8" - this setting controls the number of IConnectionMultiplexers created for comunication with Redis, default value = 1, optimal value for high loaded system connectionPoolSize= number of cors / 2 (connectionPoolSize="8" for 16 core machine)

4. Open Redis Console on Azure and clear all keys for session state by execution command: flushall
